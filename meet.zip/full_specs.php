<?php

$q=$_GET["model"];
$servername="mobiclues.c3m2ijmhxwrw.ap-south-1.rds.amazonaws.com";
$username="mobiclues";
$password="iitjstartup.m";

$conn=mysqli_connect($servername,$username,$password,'mydb',"3306");
if(!$conn){
die ("connection failed: " . mysqli_error());}


$qry="SELECT * FROM allbrands where Model_Name ='$q' LIMIT 1";
$mysql_result=mysqli_query($conn,$qry) or die("Error in firing query".mysqli_error($conn));
$numberofrows=mysqli_num_rows($mysql_result); 
 if($numberofrows){while($row = (mysqli_fetch_assoc($mysql_result))){
	 $brand=$row["Brand"];
	 $model=$row["Model_Name"];
	 $os=$row["OS"];
	 if($row["Display_Size"]==4 || $row["Display_Size"]==5 || $row["Display_Size"]==6){$display_size=(int)$row["Display_Size"];}
	 else{$display_size=$row["Display_Size"];}
	 $cpu=$row["CPU"];
	 $chipset=$row["Chipset"];
	//if($row["RAM"]>=1){ $ram=(int)$row["RAM"];}
	//else{$ram=1000*$row["RAM"];}
	$rams=$row["RAM"];
	 $rear_camera=$row["Primary_Camera"];
	 $battery=(int)$row["Battery_Capacity"];
	 $battery_removable=$row["Removable_Battery"];
//	if($row["Internal_Storage"]>=1){ $rom=(int)$row["Internal_Storage"];}
	//else{$rom=1000*$row["Internal_Storage"];}
 $roms=$row["Internal_Storage"];
	 $rom_expand=$row["Expandable"];
	 $front_camera=$row["Secondary_Camera"];
	 $wlan=$row["WLAN"];
	 $bluetooth=$row["Bluetooth"];
	 $usb=$row["USB"];
	 $dimension=$row["Dimensions"];
	 $weight=$row["Weight"];
	 $colors=$row["Colors"];
	 $released=$row["Released_In"];
	 $technology=$row["Technology"];
	 $two_g=$row["Column_2G_Band"];
	 $three_g=$row["Column_3G_bands"];
	 $four_g=$row["Column_4G_bands"];
	 $sim_type=$row["SIM_Type"];
	 $sb_ratio=$row["Screen_to_body_Ratio"];
	 $resolution=$row["Resolution"];
	 $pixel_density=$row["Pixel_Density"];
	 $multitouch=$row["Multitouch"];
	 $protection=$row["Protection"];
	 $display_type=$row["Display_Type"];
	 $gpu=$row["GPU"];
	 $slot=$row["Card_Slot"];
	 $flash=$row["Primary_Camera_Flash"];
	 $video=$row["Primary_Camera_Video_Quality"];
	 $other_feature=$row["Primary_Camera_Features"];
	 $secondary_camera_video=$row["Secondary_Camera_Video_Quality"];
	 $battery_type=$row["Battery_Type"];
	 $stand_by=$row["Stand_by"];
	 $talktime=$row["Talk_time"];
	 $fast_charging=$row["Fast_Charging"];
	 $gps=$row["GPS"];
	 $nfc=$row["NFC"];
	 $radio=$row["Radio"];
	 $usb=$row["USB"];
	 $jack=$row["Column_3_5mm_jack"];
	 $finger_print=$row["Fingerprint_Sensor"];
	 $other_sensors=$row["Other_Sensors"];
	 $pixel_density=$row["Pixel_Density"];
	 $primary_led_flash=$row["Primary_Camera_Flash"];
	 $sim_number=(int)$row["No_of_SIM"];
	 $number_of_images=$row["No_of_Image"];
	 $colors=$row["Colors"];
	 
	 
 }}
 /*
 mysqli_close($conn);*/
	?>

<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" type="image/png" href="http://mobiclues.com/images/latest icon.png" />
<link rel="stylesheet" type="text/css" href="./css/header.css">

<link rel="stylesheet" type="text/css" href="./css/full_specs.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="./scripts/index.js"></script>
<script>
window.onscroll = function(){permanent()};
function permanent(){
	if(document.body.scrollTop > 101 || document.documentElement.scrollTop > 101){
		document.getElementById("navigate").style.position = "fixed";
		document.getElementById("navigate").style.top = "0px";
		document.getElementById("navigate").style.boxShadow = "1px 1px 10px 2px #B4B4B4";
		document.getElementById("keyspecification").style.marginTop = "40px";
	}
	else{
		document.getElementById("navigate").style.boxShadow = "none"
		document.getElementById("navigate").style.position = "static";
		document.getElementById("keyspecification").style.marginTop = "8px";
	}
}
</script>
</head>
<body style="background-color:white;margin: 0px;font-family: Arial, Helvetica, sans-serif;min-width:320px;">
	
<div class="wrapper">	
	<div class="latesthead">
	<div class="threeparts" onclick="showslider()"><p style="margin-top:23px;"><i class="fa fa-bars"></i></p></div>
	<div class="threeparts" style="width:80%;"><img src="./images/new.png" style="width:110px;margin-top:22px;"></div>
	<div class="threeparts showsearch" style="float:right;"><p style="margin-top:23px;margin-right:40px;"><i class="fa fa-search"></i></p></div>
	</div>
	<div class="search showsearchbar">
		<form action="/phonefinder.php?pg_no=1" method="GET">
		<div class="searchbox" style="display:none;"><i class="fa fa-search"></i></div>
		<div style="width:100%;" >
		<input type="text" name="search" class="searchbar" placeholder = "Search for brand, products .." style="display:none;">
		</div>
		</form>
	</div>
	<script>
	$(document).ready(function(){
		$(".showsearch").click(function(){
			$(".showsearchbar").slideToggle();
			$(".searchbar").slideToggle();
			$(".searchbox").slideToggle();
		});
	});
	
	$(document).ready(function(){
		$(".images").fadeIn("slow");
	});
	</script>
	
	
	
	<div id="modal">
	<div id="slider">
	<div style="width:230px;">
	<a href=""><div class="home"><i class="fa fa-home"></i><span style="font-size:14px;margin-left:15px;"> Home </span></div></a>
	<div class="close" onclick="hideslider()"><p style="margin-top:17px;"><i class="fa fa-chevron-left"></i></p></div>
	</div>
	<div class="brandlist">
	<a href="/phonefinder.php?pg_no=%201&brand=Samsung"><p class="brandtext" style="padding-top:50px;"> Samsung Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Apple"><p class="brandtext"> Apple Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Micromax"><p class="brandtext"> Micromax Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Oppo"><p class="brandtext"> Oppo Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Vivo"><p class="brandtext"> Vivo Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Xiaomi"><p class="brandtext"> Xiaomi Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Oneplus"><p class="brandtext"> Oneplus Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Motorola"><p class="brandtext"> Motorola Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Lenovo"><p class="brandtext"> Lenovo Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Sony"><p class="brandtext"> Sony Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Asus"><p class="brandtext"> Asus Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=HTC"><p class="brandtext"> HTC Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Panasonic"><p class="brandtext"> Panasonic Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Lava"><p class="brandtext"> Lava Mobiles </p></a>
	</div>
	<div class="footerlinks">
	<a href=""><p class="brandtext"> Feedback </p></a>
	<a href=""><p class="brandtext"> Contact us </p></a>
	<a href=""><p class="brandtext"> Terms of Service </p></a>
	</div>
	<div class="connect">
	<p class="brandtext"> Connect with us </p>
	<a href="https://www.facebook.com/mobicluescom-1463581697047193/?ref=aymt_homepage_panel"><i class="fa fa-facebook social" style="margin-left:0px;"></i></a>
	<a href="https://twitter.com/mobiclues"> <i class="fa fa-twitter social"></i> </a>
	<a href="https://www.linkedin.com/company-beta/13346698/"> <i class="fa fa-linkedin social"></i> </a>
	</div>
	</div>
	</div>
	
	<a href="./mobi.php?model=<?php echo $model;?>"><div class="box" style="height:50px;border-bottom:1px solid #E0DDDD;">
	<div class="twoparts">
	<img class="smallphoto" src="http://mobiclues.com/photos/<?php echo $brand; ?>/<?php echo $model; ?>/1.jpg">
	</div>
	<div class="twoparts" style="width:calc(100% - 50px);text-align:left;	">
	<p style="margin-top:9px;"> <?php echo $brand;?> <?php echo $model;?> </p>
	<p style="margin-top:-10px;font-weight:normal;font-size:12px;"> Best Price : <span style="color:#6182A6;font-weight:600;"> &#8377 N/A </span> </p>
	</div>
	</div></a>
	<div id="navigate">
	<a href="./mobi.php?model=<?php echo $model;?>"><div class="two">Overview</div></a>
	<div class="two" style="border-right:none;color:#FD4E0C;border-bottom:2px solid #FD4E0C;font-weight:600;">Specification</div>
	</div>
	
	<div class="box" id="keyspecification">
	<p class="tilte"> Key Specs </p>
	<ul class="key-specs">
	<li class="key-points"> <?php echo $os;?> </li>
	<li class="key-points"> <?php echo $display_size;?> inches Display </li>
	<li class="key-points"> <?php echo $rear_camera;?> Rear Camera </li>
	<li class="key-points"> <?php echo $front_camera;?> Front Camera  </li>
	<li class="key-points"> <?php echo "$rams"; if($rams < 100){echo' GB';} else{ echo ' MB';} echo ' RAM';?> </li>
	<li class="key-points"> <?php echo "$roms"; echo'GB';?> Internal Storage </li>
	<li class="key-points"> <?php echo $battery; ?> mAH Battery </li>
	<?php if($finger_print !='No'){echo'<li class="key-points"> Fingerprint Sensor </li>';} ?>
	</ul>
	</div>
	
	
	<div class="box">
		<p class="tilte"> General </p>
		
		<table class="fullspecs">
		<tr class="brand">
			<td class="answer1"> Brand </td>
			<td class="answer"> <?php echo $brand;?> </td>
		</tr>
		<tr class="model name">
			<td class="answer1"> Model Name </td>
			<td class="answer"><?php echo $model;?> </td>
		</tr>
		<tr class="released on">
			<td class="answer1"> Released on </td>
			<td class="answer"> <?php echo $released;?> </td>
		</tr>
		<tr class="dimension">
			<td class="answer1"> Dimension </td>
			<td class="answer"> <?php echo $dimension;?> </td>
		</tr>
		<tr class="weight">
			<td class="answer1"> Weight </td>
			<td class="answer"> <?php echo $weight;?> </td>
		</tr>
		<tr class="colours">
			<td class="answer1"> Colours </td>
			<td class="answer"><?php echo $colors;?></td>
		</tr>
		</table>
		
		<p class="tilte"> Network </p>
		
		<table class="fullspecs-table">
		<tr class="technology">
			<td> Technology </td>
			<td class="answer"> <?php echo $technology;?> </td>
		</tr>
		<tr class="2g">
			<td> 2G </td>
			<td class="answer"> <?php echo $two_g;?> </td>
		</tr>
		<tr class="3g">
			<td> 3G </td>
			<td class="answer"> <?php echo $three_g;?> </td>
		</tr>
		<tr class="4g">
			<td> 4G </td>
			<td class="answer"> <?php echo $four_g;?> </td>
		</tr>
		<tr class="sim type">
			<td> SIM Type </td>
			<td class="answer"> <?php echo $sim_type;?></td>
		</tr>
		</table>
		
		<p class="tilte"> Display </p>
		<table class="fullspecs-table">
		<tr class="display size">
			<td> Display Size </td>
			<td class="answer"> <?php echo $display_size;?> inches </td>
		</tr>
		<tr class="screen to body">
			<td> Screen-to-body Ratio </td>
			<td class="answer"> <?php echo $sb_ratio;?> </td>
		</tr>
		<tr class="resolution">
			<td> Resolution </td>
			<td class="answer"><?php echo $resolution;?> </td>
		</tr>
		<tr class="pixel density">
			<td> Pixel Density </td>
			<td class="answer"> <?php echo $pixel_density;?></td>
		</tr>
		<tr class="multitouch">
			<td>Multitouch</td>
			<td class="answer"> <?php echo $multitouch;?></td>
		</tr>
		<tr class="protection">
			<td>Protection</td>
			<td class="answer"> <?php echo $protection;?>  </td>
		</tr>
		<tr class="display type">
			<td>Display Type</td>
			<td class="answer"> <?php echo $display_type;?> </td>
		</tr>
		</table>
		
		
		<p class="tilte"> Software </p>
		<table class="fullspecs-table">
		<tr class="operating system">
			<td> Operating System </td>
			<td class="answer"> <?php echo $os;?></td>
		</tr>
		</table>
		
		<p class="tilte"> Performance </p>
		<table class="fullspecs-table">
		<tr class="chipset">
			<td> Chipset </td>
			<td class="answer"><?php echo $chipset;?></td>
		</tr>
		<tr class="cpu">
			<td>CPU</td>
			<td class="answer"><?php echo $cpu;?></td>
		</tr>
		<tr class="gpu">
			<td> GPU </td>
			<td class="answer"><?php echo $gpu;?></td>
		</tr>
		<tr class="ram">
			<td> RAM </td>
			<td class="answer"> <?php echo (int)$ram[0].' GB';?> </td>
		</tr>
		</table>
		
		<p class="tilte"> Storage </p>
		<table class="fullspecs-table">
		<tr class="internal storage">
			<td> Internal Storage </td>
			<td class="answer"> <?php echo (int)$rom[0].' GB';?> </td>
		</tr>
		<tr class="expandable">
			<td>Expandable</td>
			<td class="answer"><?php echo $rom_expand;?></td>
		</tr>
		<tr class="slot type">
			<td>Slot Type</td>
			<td class="answer"><?php echo $slot;?></td>
		</tr>
		</table>
		
		<p class="tilte"> Primary Camera </p>
		<table class="fullspecs-table">
		<tr class="primary camera">
			<td> Primary Camera </td>
			<td class="answer"><?php echo $rear_camera;?> </td>
		</tr>
		<tr class="aperture">
			<td> Aperture </td>
			<td class="answer"> null </td>
		</tr>
		<tr class="flash">
			<td>Flash</td>
			<td class="answer"><?php echo $flash;?></td>
		</tr>
		<tr class="primary camera video">
			<td> Video </td>
			<td class="answer"><?php echo $video;?></td>
		</tr>
		<tr class="other features">
			<td> Other Features </td>
			<td class="answer"> <?php echo $other_feature;?></td>
		</tr>
		</table>
		
		<p class="tilte"> Secondary Camera </p>
		<table class="fullspecs-table">
		<tr class="secondary camera">
			<td> Secondary Camera </td>
			<td class="answer"><?php echo $front_camera;?></td>
		</tr>
		<tr class="secondary camera video">
			<td> Video </td>
			<td class="answer"> <?php echo $secondary_camera_video;?> </td>
		</tr>
		</table>
		
		<p class="tilte"> Battery </p>
		<table class="fullspecs-table">
		<tr class="capacity">
			<td> Capacity </td>
			<td class="answer"> <?php echo $battery; ?> mAH</td>
		</tr>
		<tr class="type">
			<td> Type </td>
			<td class="answer"> <?php echo $battery_type;?> </td>
		</tr>
		<tr class="removable">
			<td>Removable</td>
			<td class="answer"> <?php echo $battery_removable;?></td>
		</tr>
		<tr class="stand-by">
			<td> Stand-by </td>
			<td class="answer"> <?php echo $stand_by;?></td>
		</tr>
		<tr class="talktime">
			<td> Talktime </td>
			<td class="answer"> <?php echo $talktime;?></td>
		</tr>
		<tr class="fast charging">
			<td> Fast Charging </td>
			<td class="answer"> <?php echo $fast_charging;?></td>
		</tr>
		</table>
		
		<p class="tilte"> Connectivity </p>
		<table class="fullspecs-table">
		<tr class="wlan">
			<td> WLAN </td>
			<td class="answer"><?php echo $wlan;?></td>
		</tr>
		<tr class="bluetooth">
			<td>Bluetooth </td>
			<td class="answer"><?php echo $bluetooth;?></td>
		</tr>
		<tr class="gps">
			<td>Gps</td>
			<td class="answer"><?php echo $gps;?></td>
		</tr>
		<tr class="nfc">
			<td> NFC </td>
			<td class="answer"> <?php echo $nfc;?></td>
		</tr>
		<tr class="radio">
			<td> Radio </td>
			<td class="answer"> <?php echo $radio;?></td>
		</tr>
		<tr class="usb">
			<td> USB </td>
			<td class="answer"> <?php echo $usb;?></td>
		</tr>
		<tr class="3.5mm jack">
			<td> 3.5 mm Audio Jack </td>
			<td class="answer"><?php echo $jack;?></td>
		</tr>
		</table>
		
		<p class="tilte"> Sensors </p>
		<table class="fullspecs-table">
		<tr class="fingerprint sensor">
			<td>Fingerprint Sensor </td>
			<td class="answer"><?php echo $finger_print;?></td>
		</tr>
		<tr class="other sensors">
			<td> Other Sensors </td>
			<td class="answer"><?php echo $other_sensors;?> </td>
		</tr>
		</table>
		
	</div>
	
</div>
</body>
</html>