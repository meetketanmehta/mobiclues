var hide = document.getElementsByClassName("variant-collection");
var storage = document.getElementsByClassName("storage-box");
var ram = document.getElementsByClassName("ram-box");
if(storage.length == 1){
	hide[1].style.display = "none";
}
if(ram.length == 1){
	hide[2].style.display = "none";
}