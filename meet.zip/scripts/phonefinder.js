var y = document.getElementById("modal1");
window.onclick = function(event) {
    if (event.target == modal1) {
        modal1.style.display = "none";
	}
}
function sort-options(){
	document.getElementById("modal1").style.display = "block";
}