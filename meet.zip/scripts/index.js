function showslider() {
    document.getElementById("modal").style.left = "0px";
	document.getElementById("slider").style.left = "0px";
	document.getElementById("slider").style.boxShadow = "1px 1px 20px 1px ";
}
function hideslider(){
	document.getElementById("modal").style.left = "-100%";
	document.getElementById("slider").style.left = "-100%";
	document.getElementById("slider").style.boxShadow = "none ";
}
var x = document.getElementById("modal");
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.left = "-100%";
		document.getElementById("slider").style.left = "-100%";
		document.getElementById("slider").style.boxShadow = "none ";
    }
}

window.onscroll = function(){navigation()};
function navigation(){
	if(document.body.scrollTop > 45 || document.documentElement.scrollTop > 45){
		document.getElementById("headerperm").style.position = "fixed";
		document.getElementById("headerperm").style.display = "block";
	}
	else{
		document.getElementById("headerperm").style.display = "none";
	}
}

window.onscroll = function(){permanent()};
function permanent(){
	if(document.body.scrollTop > 101 || document.documentElement.scrollTop > 101){
		document.getElementById("navigate").style.position = "fixed";
		document.getElementById("navigate").style.top = "0px";
		document.getElementById("navigate").style.boxShadow = "1px 1px 10px 2px #B4B4B4";
		document.getElementById("photo-container").style.marginTop = "47px";
	}
	else{
		document.getElementById("navigate").style.boxShadow = "none"
		document.getElementById("navigate").style.position = "static";
		document.getElementById("photo-container").style.marginTop = "8px";
	}
}