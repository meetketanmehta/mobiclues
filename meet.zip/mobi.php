<?php

$q=$_GET["model"];
$servername="mobiclues.c3m2ijmhxwrw.ap-south-1.rds.amazonaws.com";
$username="mobiclues";
$password="iitjstartup.m";

$conn=mysqli_connect($servername,$username,$password,'mydb',"3306");
if(!$conn){
die ("connection failed: " . mysqli_error());}


$qry="SELECT * FROM allbrands where Model_Name ='$q' LIMIT 1";
$mysql_result=mysqli_query($conn,$qry) or die("Error in firing query".mysqli_error($conn));
$numberofrows=mysqli_num_rows($mysql_result); 
 if($numberofrows){while($row = (mysqli_fetch_assoc($mysql_result))){
	 $brand=$row["Brand"];
	 $model=$row["Model_Name"];
	 $os=$row["OS"];
	 if($row["Display_Size"]==4 || $row["Display_Size"]==5 || $row["Display_Size"]==6){$display_size=(int)$row["Display_Size"];}
	 else{$display_size=$row["Display_Size"];}
	 $cpu=$row["CPU"];
	 $chipset=$row["Chipset"];
	//if($row["RAM"]>=1){ $ram=(int)$row["RAM"];}
	//else{$ram=1000*$row["RAM"];}
	$rams=$row["RAM"];
	 $rear_camera=$row["Primary_Camera"];
	 $battery=(int)$row["Battery_Capacity"];
	 $battery_removable=$row["Removable_Battery"];
//	if($row["Internal_Storage"]>=1){ $rom=(int)$row["Internal_Storage"];}
	//else{$rom=1000*$row["Internal_Storage"];}
 $roms=$row["Internal_Storage"];
	 $rom_expand=$row["Expandable"];
	 $front_camera=$row["Secondary_Camera"];
	 $wlan=$row["WLAN"];
	 $bluetooth=$row["Bluetooth"];
	 $usb=$row["USB"];
	 $dimension=$row["Dimensions"];
	 $weight=$row["Weight"];
	 $colors=$row["Colors"];
	 $released=$row["Released_In"];
	 $technology=$row["Technology"];
	 $two_g=$row["Column_2G_Band"];
	 $three_g=$row["Column_3G_bands"];
	 $four_g=$row["Column_4G_bands"];
	 $sim_type=$row["SIM_Type"];
	 $sb_ratio=$row["Screen_to_body_Ratio"];
	 $resolution=$row["Resolution"];
	 $pixel_density=$row["Pixel_Density"];
	 $multitouch=$row["Multitouch"];
	 $protection=$row["Protection"];
	 $display_type=$row["Display_Type"];
	 $gpu=$row["GPU"];
	 $slot=$row["Card_Slot"];
	 $flash=$row["Primary_Camera_Flash"];
	 $video=$row["Primary_Camera_Video_Quality"];
	 $other_feature=$row["Primary_Camera_Features"];
	 $secondary_camera_video=$row["Secondary_Camera_Video_Quality"];
	 $battery_type=$row["Battery_Type"];
	 $stand_by=$row["Stand_by"];
	 $talktime=$row["Talk_time"];
	 $fast_charging=$row["Fast_Charging"];
	 $gps=$row["GPS"];
	 $nfc=$row["NFC"];
	 $radio=$row["Radio"];
	 $usb=$row["USB"];
	 $jack=$row["Column_3_5mm_jack"];
	 $finger_print=$row["Fingerprint_Sensor"];
	 $other_sensors=$row["Other_Sensors"];
	 $pixel_density=$row["Pixel_Density"];
	 $primary_led_flash=$row["Primary_Camera_Flash"];
	 $sim_number=(int)$row["No_of_SIM"];
	 $number_of_images=$row["No_of_Image"];
	 $colors=$row["Colors"];
	 
	 
 }}
 /*
 mysqli_close($conn);*/
	?>
	
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" type="image/png" href="http://mobiclues.com/images/latest icon.png" />
<link rel="stylesheet" type="text/css" href="./slick/slick.css">
<link rel="stylesheet" type="text/css" href="./slick/slick-theme.css">
<link rel="stylesheet" type="text/css" href="./css/mobi.css">
<link rel="stylesheet" type="text/css" href="./css/header.css">
<script src="./scripts/index.js"></script>
<script src="./scripts/mobi.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
window.onscroll = function(){permanent()};
function permanent(){
	if(document.body.scrollTop > 101 || document.documentElement.scrollTop > 101){
		document.getElementById("navigate").style.position = "fixed";
		document.getElementById("navigate").style.top = "0px";
		document.getElementById("navigate").style.boxShadow = "1px 1px 10px 2px #B4B4B4";
		document.getElementById("photo-container").style.marginTop = "40px";
	}
	else{
		document.getElementById("navigate").style.boxShadow = "none"
		document.getElementById("navigate").style.position = "static";
		document.getElementById("photo-container").style.marginTop = "8px";
	}
}
</script>
</head>
<body style="background-color:#efeded;margin: 0px;font-family: Arial, Helvetica, sans-serif;">
<?php $ram=explode(", " , $rams); ?>
<?php $rom=explode(", " , $roms); ?> 
<div class="wrapper">
	<div class="latesthead">
	<div class="threeparts" onclick="showslider()"><p style="margin-top:23px;"><i class="fa fa-bars"></i></p></div>
	<div class="threeparts" style="width:80%;"><img src="./images/new.png" style="width:110px;margin-top:22px;"></div>
	<div class="threeparts showsearch" style="float:right;"><p style="margin-top:23px;margin-right:40px;"><i class="fa fa-search"></i></p></div>
	</div>
	<div class="search showsearchbar">
		<form action="/phonefinder.php?pg_no=1" method="GET">
		<div class="searchbox" style="display:none;"><i class="fa fa-search"></i></div>
		<div style="width:100%;" >
		<input type="text" name="search" class="searchbar" placeholder = "Search for brand, products .." style="display:none;">
		</div>
		</form>
	</div>
	<script>
	$(document).ready(function(){
		$(".showsearch").click(function(){
			$(".showsearchbar").slideToggle();
			$(".searchbar").slideToggle();
			$(".searchbox").slideToggle();
		});
	});
	
	$(document).ready(function(){
		$(".images").fadeIn("slow");
	});
	</script>
	
	<div id="modal">
	<div id="slider">
	<div style="width:230px;">
	<a href=""><div class="home"><i class="fa fa-home"></i><span style="font-size:14px;margin-left:15px;"> Home </span></div></a>
	<div class="close" onclick="hideslider()"><p style="margin-top:17px;"><i class="fa fa-chevron-left"></i></p></div>
	</div>
	<div class="brandlist">
	<a href="/phonefinder.php?pg_no=%201&brand=Samsung"><p class="brandtext" style="padding-top:50px;"> Samsung Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Apple"><p class="brandtext"> Apple Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Micromax"><p class="brandtext"> Micromax Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Oppo"><p class="brandtext"> Oppo Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Vivo"><p class="brandtext"> Vivo Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Xiaomi"><p class="brandtext"> Xiaomi Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Oneplus"><p class="brandtext"> Oneplus Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Motorola"><p class="brandtext"> Motorola Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Lenovo"><p class="brandtext"> Lenovo Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Sony"><p class="brandtext"> Sony Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Asus"><p class="brandtext"> Asus Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=HTC"><p class="brandtext"> HTC Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Panasonic"><p class="brandtext"> Panasonic Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Lava"><p class="brandtext"> Lava Mobiles </p></a>
	</div>
	<div class="footerlinks">
	<a href=""><p class="brandtext"> Feedback </p></a>
	<a href=""><p class="brandtext"> Contact us </p></a>
	<a href=""><p class="brandtext"> Terms of Service </p></a>
	</div>
	<div class="connect">
	<p class="brandtext"> Connect with us </p>
	<a href="https://www.facebook.com/mobicluescom-1463581697047193/?ref=aymt_homepage_panel"><i class="fa fa-facebook social" style="margin-left:0px;"></i></a>
	<a href="https://twitter.com/mobiclues"> <i class="fa fa-twitter social"></i> </a>
	<a href="https://www.linkedin.com/company-beta/13346698/"> <i class="fa fa-linkedin social"></i> </a>
	</div>
	</div>
	</div>
	
	<div class="box" style="height:50px;border-bottom:1px solid #E0DDDD;">
	<div class="twoparts">
	<img class="smallphoto" src="http://mobiclues.com/photos/<?php echo $brand; ?>/<?php echo $model; ?>/1.jpg">
	</div>
	<div class="twoparts" style="width:calc(100% - 50px);text-align:left;	">
	<p style="margin-top:9px;"> <?php echo $brand;?> <?php echo $model;?> </p>
	<p style="margin-top:-10px;font-weight:normal;font-size:12px;"> Best Price : <span style="color:#6182A6;font-weight:600;"> &#8377 N/A </span> </p>
	</div>
	</div>
	
	<div id="navigate">
	<div class="two" style="color:#FD4E0C;border-bottom:2px solid #FD4E0C;font-weight:600;">Overview</div>
	<a href="./full_specs.php?model=<?php echo $model; ?>"><div class="two" style="border-right:none;">Specification</div></a>
	</div>
	
	<div id="photo-container">
	<div class="regular slider photos">
		<?php
			for( $x=1; $x <= $number_of_images;$x++){
			echo'<div> <img src="http://mobiclues.com/photos/'; echo $brand; echo '/'; echo $model; echo'/';echo"$x";echo'.jpg" class="mobipic"> </div>';
		}?>
	</div>
	</div>
	<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
	<script src="./slick/slick.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript">
		$(document).on('ready', function() {
		$(".regular").slick({
        dots:true,
        infinite: false,
        slidesToShow: 1,
        slidesToScroll:1
		});
		});
	</script>
	

	<div class="variants">
	
	<div class="variant-collection">
	<div class="variant-title">
	<p> INTERNAL STORAGE </p>
	</div>
	<div class="option-collection">
	<?php
		$x=0;
		while(isset($rom[$x])){
		echo'<div class="options storage-box">'; echo (int)"$rom[$x]"; echo 'GB </div>';
		$x++;
		} 
	?>
	</div>
	</div>
	
	<div class="variant-collection">
	<div class="variant-title">
	<p> RAM </p>
	</div>
	<div class="option-collection">
	<?php
		$x=0;
		while(isset($ram[$x])){
		echo'<div class="options ram-box">';echo(int)"$ram[$x]"; echo 'GB </div>';
		$x++;
		}
	?>
	</div>
	</div>
	
	<div class="variant-collection">
	<div class="variant-title">
	<p> COLOURS </p>
	</div>
	<div class="option-collection">
	<div class="options" style="border: 1px solid #0063d6;background-color:#d6e9ff;color:#0063d6;">All</div>
	<?php $colour=explode( ", " , $colors );?>
	<?php
		$x=0;
		while(isset($colour[$x])){
		echo'<div class="options color-box">';echo $colour[$x];echo'</div>';
		$x++;
		}
	?>
	</div>
	</div>
	
	</div>
	
	<script>
	var hide = document.getElementsByClassName("variant-collection");
	var storage = document.getElementsByClassName("storage-box");
	var ram = document.getElementsByClassName("ram-box");
	var color = document.getElementsByClassName("color-box");
	if(color.length == 2){
		color[0].style.display = "none";
	}
	if(storage.length == 1){
		hide[0].style.display = "none";
	}
	if(ram.length == 1){
		hide[1].style.display = "none";
	}
	</script>
	
	<div class="box">
	<div class="box-title">
	<p> Price in India </p>
	</div>
	<div class="store">
	<div class="store-img">
	<img class="store-photo" src="http://mobiclues.com/images/logos/flipkart_logo.jpg">
	</div>
	<div class="store-price-box">
	<p class="store-price"> <span class="price-color">&#8377 N/A</span></p>
	</div>
	<div class="store-link-box" style="	width:auto;">
	<div class="store-link">Buy</div>
	</div>
	</div>
	<div class="store">
	<div class="store-img">
	<img class="store-photo" src="http://mobiclues.com/images/logos/amazon_logo.jpg">
	</div>
	<div class="store-price-box">
	<p class="store-price"> <span class="price-color">&#8377 N/A</span></p>
	</div>
	<div class="store-link-box" style="	width:auto;">
	<div class="store-link">Buy</div>
	</div>
	</div>
	<div class="store">
	<div class="store-img" >
	<img class="store-photo" src="http://mobiclues.com/images/logos/snapdeal_logo.jpg">
	</div>
	<div class="store-price-box">
	<p class="store-price"> <span class="price-color">&#8377 N/A</span></p>
	</div>
	<div class="store-link-box" style="	width:auto;">
	<div class="store-link">Buy</div>
	</div>
	</div>
	<div class="store">
	<div class="store-img">
	<img class="store-photo" src="http://mobiclues.com/images/logos/ebay_logo.jpg">
	</div>
	<div class="store-price-box">
	<p class="store-price"> <span class="price-color">&#8377 N/A</span></p>
	</div>
	<div class="store-link-box" style="	width:auto;">
	<div class="store-link">Buy</div>
	</div>
	</div>
	<div class="store">
	<div class="store-img" >
	<img class="store-photo" src="http://mobiclues.com/images/logos/tata-cliq_logo.jpg">
	</div>
	<div class="store-price-box">
	<p class="store-price"> <span class="price-color">&#8377 N/A</span></p>
	</div>
	<div class="store-link-box" style="	width:auto;">
	<div class="store-link">Buy</div>
	</div>
	</div>
	</div>
	
	<div class="box">
	<div class="box-title">
	<p> Key Specs <a href="./full_specs.php?model=<?php echo $model; ?>"><span style="color:#FD4E0C;margin-left:20px;font-size:11px;"> See Full Specification <i class="fa fa-caret-right"></i> </span></a> </p>
	</div>
	<ul class="key-specs">
	<li class="key-points"> <?php echo $os;?> </li>
	<li class="key-points"> <?php echo $display_size;?> inches Display </li>
	<li class="key-points"> <?php echo $rear_camera;?> Rear Camera </li>
	<li class="key-points"> <?php echo $front_camera;?> Front Camera  </li>
	<li class="key-points"> <?php echo "$rams"; if($rams < 100){echo' GB';} else{ echo ' MB';} echo ' RAM';?> </li>
	<li class="key-points"> <?php echo "$roms"; echo' GB';?> Internal Storage </li>
	<li class="key-points"> <?php echo $battery; ?> mAH Battery </li>
	<?php if($finger_print !='No'){echo'<li class="key-points"> Fingerprint Sensor </li>';} ?>
	</ul>
	</div>
	
	<div class="box">
	<div class="box-title">
	<p> Rating and Review </p>
	</div>
	<div class="small-logo-box">
		<div class="small-logo" style="border-bottom:2px solid #FD4E0C;"><img class="small-icon" src="./images/logos/flipkart_small_logo.jpg"></div>
		<div class="small-logo"><img class="small-icon" src="./images/logos/amazon_small_logo.jpg"></div>
		<div class="small-logo"><img class="small-icon" src="./images/logos/snapdeal_small_logo.jpg"></div>
		<div class="small-logo"><img class="small-icon" src="./images/logos/tatacliq_small_logo.jpg"></div>
		<div class="small-logo"><img class="small-icon" src="./images/logos/ebay_small_logo.jpg"></div>
	</div>
	<div class="review-box">
	<p class="seller-title"> Seller : Flipkart Seller </p>
	<p class="seller-rating"> 4.5 / 5 </p>
	<p class="seller-review"> Read all 5140 reviews <i class="fa fa-angle-double-right"></i></p>
	</div>
	</div>
	
	<div class="box">
	<div class="box-title" style="border-bottom:none;">
	<p> Similar Products </p>
	</div>
	<div class="latest" style="height:2560px;margin-top:0px;border-top:none;">
	<div class="mobilesparts">
	<div class="shortmobile" style="border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Oneplus/5/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Oneplus 5 </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p>
	<div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Motorola/Moto C Plus/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Motorola Moto C Plus </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p>
	<div class="buyfrom">
	<img class="buyfromlogo" src="./images/logos/flipkart_small_logo.jpg">
	</div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile">
	<div style="height:105px;"><img class="images" src="./photos/Xiaomi/Redmi 4/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Xiaomi Redmi 4 </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p>
	<div class="buyfrom">
	<img class="buyfromlogo" src="./images/logos/snapdeal_small_logo.jpg">
	</div>
	</div>
	<div class="shortmobile" style="border:none;">
	<div style="height:105px;"><img class="images" src="./photos/Motorola/Moto Z2 Play/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Motorola Moto Z2 Play</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p>
	<div class="buyfrom">
	<img class="buyfromlogo" src="./images/logos/tatacliq_small_logo.jpg">
	</div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile" style="border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Sony/Xperia XZ Premium/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Sony Xperia XZ Premium </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Samsung/Galaxy S8+/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle">Samsung Galaxy S8+</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p>
	<div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile">
	<div style="height:105px;"><img class="images" src="./photos/Vivo/V5s/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Vivo V5s </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;">
	<div style="height:105px;"><img class="images" src="./photos/Oppo/F3/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Oppo F3</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile" style="border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Samsung/Galaxy J3 Pro/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Samsung Galaxy J3 Pro </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Yu/Yureka Black/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle">Yu Yureka Black</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile">
	<div style="height:105px;"><img class="images" src="./photos/Asus/Zenfone Live ZB501KL/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Asus Zenfone Live </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;">
	<div style="height:105px;"><img class="images" src="./photos/Samsung/On Nxt/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Samsung On Nxt</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
		<div class="mobilesparts">
	<div class="shortmobile" style="border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Sony/Xperia XA1/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Sony Xperia XA1 </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Sony/Xperia XZs/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle">Sony Xperia XZs</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile">
	<div style="height:105px;"><img class="images" src="./photos/Asus/Zenfone 3 Laser/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Asus Zenfone 3 Laser </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;">
	<div style="height:105px;"><img class="images" src="./photos/Panasonic/Eluga Ray X/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Panasonic Ray X</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile" style="border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Samsung/Galaxy On7/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Samsung Galaxy On7 </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Vivo/Y55s/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle">Vivo Y55s</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile">
	<div style="height:105px;"><img class="images" src="./photos/Motorola/Moto G5 Plus/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Motorola Moto G5 Plus </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;">
	<div style="height:105px;"><img class="images" src="./photos/Panasonic/Eluga Ray Max/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Panasonic Ray Max</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile" style="border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Samsung/Galaxy On7/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Samsung Galaxy On7 </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Vivo/Y55s/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle">Vivo Y55s</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile">
	<div style="height:105px;"><img class="images" src="./photos/Motorola/Moto G5 Plus/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Motorola Moto G5 Plus </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;">
	<div style="height:105px;"><img class="images" src="./photos/Panasonic/Eluga Ray Max/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Panasonic Ray Max</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile" style="border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Samsung/Galaxy On7/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Samsung Galaxy On7 </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Vivo/Y55s/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle">Vivo Y55s</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile">
	<div style="height:105px;"><img class="images" src="./photos/Motorola/Moto G5 Plus/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Motorola Moto G5 Plus </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;">
	<div style="height:105px;"><img class="images" src="./photos/Panasonic/Eluga Ray Max/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Panasonic Ray Max</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile" style="border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Samsung/Galaxy On7/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Samsung Galaxy On7 </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;border-right:1px solid #E0DDDD;">
	<div style="height:105px;"><img class="images" src="./photos/Vivo/Y55s/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle">Vivo Y55s</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	<div class="mobilesparts">
	<div class="shortmobile">
	<div style="height:105px;"><img class="images" src="./photos/Motorola/Moto G5 Plus/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Motorola Moto G5 Plus </p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	<div class="shortmobile" style="border:none;">
	<div style="height:105px;"><img class="images" src="./photos/Panasonic/Eluga Ray Max/1.jpg" style="max-height:90px;max-width:140px;margin-top:15px;"></div>
	<p class="phonetitle shortphonetitle"> Panasonic Ray Max</p>
	<p class="phoneprice shortphoneprice">&#8377 N/A</p><div class="buyfrom"><img class="buyfromlogo" src="./images/logos/amazon_small_logo.jpg"></div>
	</div>
	</div>
	</div>
	</div>
</div>
</body>
</html>