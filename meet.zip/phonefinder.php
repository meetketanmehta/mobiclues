<?php if(isset($_GET[brand])){$q=$_GET["brand"];}?>

<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" type="image/png" href="http://mobiclues.com/images/latest icon.png" />
<link rel="stylesheet" type="text/css" href="./css/phonefinder.css">
<link rel="stylesheet" type="text/css" href="./css/header.css">
<script src="./scripts/index.js"></script>
<script src="./scripts/phonefinder.js"></script>
<script src="./scripts/ajax_filter.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body style="background-color:#efeded;margin: 0px;font-family: Arial, Helvetica, sans-serif;">
<div class="wrapper">
	<div class="latesthead">
	<div class="threeparts" onclick="showslider()"><p style="margin-top:23px;"><i class="fa fa-bars"></i></p></div>
	<div class="threeparts" style="width:80%;"><img src="./images/new.png" style="width:110px;margin-top:22px;"></div>
	<div class="threeparts showsearch" style="float:right;"><p style="margin-top:23px;margin-right:40px;"><i class="fa fa-search"></i></p></div>
	</div>
	<div class="search showsearchbar">
		<form action="/phonefinder.php?pg_no=1" method="GET">
		<div class="searchbox" style="display:none;"><i class="fa fa-search"></i></div>
		<div style="width:100%;" >
		<input type="text" name="search" class="searchbar" placeholder = "Search for brand, products .." style="display:none;">
		</div>
		</form>
	</div>
	<script>
	$(document).ready(function(){
		$(".showsearch").click(function(){
			$(".showsearchbar").slideToggle();
			$(".searchbar").slideToggle();
			$(".searchbox").slideToggle();
		});
	});
	
	$(document).ready(function(){
		$(".images").fadeIn("slow");
	});
	</script>
	
	<div id="modal">
	<div id="slider">
	<div style="width:230px;">
	<a href=""><div class="home"><i class="fa fa-home"></i><span style="font-size:14px;margin-left:15px;"> Home </span></div></a>
	<div class="close" onclick="hideslider()"><p style="margin-top:17px;"><i class="fa fa-chevron-left"></i></p></div>
	</div>
	<div class="brandlist">
	<a href="/phonefinder.php?pg_no=%201&brand=Samsung"><p class="brandtext" style="padding-top:50px;"> Samsung Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Apple"><p class="brandtext"> Apple Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Micromax"><p class="brandtext"> Micromax Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Oppo"><p class="brandtext"> Oppo Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Vivo"><p class="brandtext"> Vivo Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Xiaomi"><p class="brandtext"> Xiaomi Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Oneplus"><p class="brandtext"> Oneplus Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Motorola"><p class="brandtext"> Motorola Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Lenovo"><p class="brandtext"> Lenovo Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Sony"><p class="brandtext"> Sony Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Asus"><p class="brandtext"> Asus Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=HTC"><p class="brandtext"> HTC Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Panasonic"><p class="brandtext"> Panasonic Mobiles </p></a>
	<a href="/phonefinder.php?pg_no=%201&brand=Lava"><p class="brandtext"> Lava Mobiles </p></a>
	</div>
	<div class="footerlinks">
	<a href=""><p class="brandtext"> Feedback </p></a>
	<a href=""><p class="brandtext"> Contact us </p></a>
	<a href=""><p class="brandtext"> Terms of Service </p></a>
	</div>
	<div class="connect">
	<p class="brandtext"> Connect with us </p>
	<a href="https://www.facebook.com/mobicluescom-1463581697047193/?ref=aymt_homepage_panel"><i class="fa fa-facebook social" style="margin-left:0px;"></i></a>
	<a href="https://twitter.com/mobiclues"> <i class="fa fa-twitter social"></i> </a>
	<a href="https://www.linkedin.com/company-beta/13346698/"> <i class="fa fa-linkedin social"></i> </a>
	</div>
	</div>
	</div>
	
		<script>




function loadDoc(stra1,stra2,stra3,stra4,stra5,stra6,stra7,stra8,stra9,stra10,stra11,str12){


	var a1=document.getElementById("a1").checked;
	var a2=document.getElementById("a2").checked;
	var a3=document.getElementById("a3").checked;
	var a4=document.getElementById("a4").checked;
	var a5=document.getElementById("a5").checked;
	var a6=document.getElementById("a6").checked;
	var a7=document.getElementById("a7").checked;
	var a8=document.getElementById("a8").checked;
	var a9=document.getElementById("a9").checked;
	var a10=document.getElementById("a10").checked;
	var a11=document.getElementById("a11").checked;
	var a12=document.getElementById("a12").checked;
	var a13=document.getElementById("a13").checked;
	var a14=document.getElementById("a14").checked;
	var a15=document.getElementById("a15").checked;
	var a16=document.getElementById("a16").checked;
	var a17=document.getElementById("a17").checked;
	var a18=document.getElementById("a18").checked;
	var a19=document.getElementById("a19").checked;
	var a20=document.getElementById("a20").checked;
	var a21=document.getElementById("a21").checked;
	var a22=document.getElementById("a22").checked;
	var a23=document.getElementById("a23").checked;
	var a24=document.getElementById("a24").checked;
	var a25=document.getElementById("a25").checked;
	var a26=document.getElementById("a26").checked;
	var a27=document.getElementById("a27").checked;
	var a28=document.getElementById("a28").checked;
	var a29=document.getElementById("a29").checked;





	if(a1){stra1=stra1+"Acer  ";}
	if(a2){stra1=stra1+"Alcatel  ";}
	if(a3){stra1=stra1+"Apple  ";}
	if(a4){stra1=stra1+"Asus  ";}
	if(a5){stra1=stra1+"Blackberry  ";}
	if(a6){stra1=stra1+"Gionee  ";}
	if(a7){stra1=stra1+"Google  ";}
	if(a8){stra1=stra1+"HTC  ";}
	if(a9){stra1=stra1+"Huawei  ";}
	if(a10){stra1=stra1+"Karbonn  ";}
	if(a11){stra1=stra1+"Lava  ";}
	if(a12){stra1=stra1+"Leeco  ";}
	if(a13){stra1=stra1+"Lenovo  ";}
	if(a14){stra1=stra1+"LG  ";}
	if(a15){stra1=stra1+"Meizu  ";}
	if(a16){stra1=stra1+"Micromax  ";}
	if(a17){stra1=stra1+"Microsoft  ";}
	if(a18){stra1=stra1+"Motorola  ";}
	if(a19){stra1=stra1+"Nokia  ";}
	if(a20){stra1=stra1+"Oneplus  ";}
	if(a21){stra1=stra1+"Oppo  ";}
	if(a22){stra1=stra1+"Panasonic  ";}
	if(a23){stra1=stra1+"Samsung  ";}
	if(a24){stra1=stra1+"Sony  ";}
	if(a25){stra1=stra1+"Vivo  ";}
	if(a26){stra1=stra1+"Xiaomi  ";}
	if(a27){stra1=stra1+"Xolo  ";}
	if(a28){stra1=stra1+"YU  ";}
	if(a29){stra1=stra1+"ZTE  ";}



	var b1=document.getElementById("b1").checked;
	var b2=document.getElementById("b2").checked;
	var b3=document.getElementById("b3").checked;
	var b4=document.getElementById("b4").checked;
	var b5=document.getElementById("b5").checked;
	var b6=document.getElementById("b6").checked;
	var b7=document.getElementById("b7").checked;
	var b8=document.getElementById("b8").checked;
	var b9=document.getElementById("b9").checked;

	if(b1){stra2=stra2+"b1  ";}
	if(b2){stra2=stra2+"b2  ";}
	if(b3){stra2=stra2+"b3  ";}
	if(b4){stra2=stra2+"b4  ";}
	if(b5){stra2=stra2+"b5  ";}
	if(b6){stra2=stra2+"b6  ";}
	if(b7){stra2=stra2+"b7  ";}
	if(b8){stra2=stra2+"b8  ";}
	if(b9){stra2=stra2+"b9  ";}


	var c1=document.getElementById("c1").checked;
	var c2=document.getElementById("c2").checked;
	var c3=document.getElementById("c3").checked;
	var c4=document.getElementById("c4").checked;
	var c5=document.getElementById("c5").checked;
	var c6=document.getElementById("c6").checked;
	var c7=document.getElementById("c7").checked;

	if(c1){stra3=stra3+"c1  ";}
	if(c2){stra3=stra3+"c2  ";}
	if(c3){stra3=stra3+"c3  ";}
	if(c4){stra3=stra3+"c4  ";}
	if(c5){stra3=stra3+"c5  ";}
	if(c6){stra3=stra3+"c6  ";}
	if(c7){stra3=stra3+"c7  ";}


	var d1=document.getElementById("d1").checked;
	var d2=document.getElementById("d2").checked;
	var d3=document.getElementById("d3").checked;
	var d4=document.getElementById("d4").checked;
	var d5=document.getElementById("d5").checked;

	if(d1){stra4=stra4+"d1  ";}
	if(d2){stra4=stra4+"d2  ";}
	if(d3){stra4=stra4+"d3  ";}
	if(d4){stra4=stra4+"d4  ";}
	if(d5){stra4=stra4+"d5  ";}


	var e1=document.getElementById("e1").checked;
	var e2=document.getElementById("e2").checked;
	var e3=document.getElementById("e3").checked;
	var e4=document.getElementById("e4").checked;
	var e5=document.getElementById("e5").checked;

	if(e1){stra5=stra5+"e1  ";}
	if(e2){stra5=stra5+"e2  ";}
	if(e3){stra5=stra5+"e3  ";}
	if(e4){stra5=stra5+"e4  ";}
	if(e5){stra5=stra5+"e5  ";}


	var f1=document.getElementById("f1").checked;
	var f2=document.getElementById("f2").checked;
	var f4=document.getElementById("f4").checked;
	var f5=document.getElementById("f5").checked;

	if(f1){stra6=stra6+"Android  ";}
	if(f2){stra6=stra6+"iOS  ";}
	if(f4){stra6=stra6+"Blackberry  ";}
	if(f5){stra6=stra6+"Windows  ";}


	var g1=document.getElementById("g1").checked;
	var g2=document.getElementById("g2").checked;
	var g3=document.getElementById("g3").checked;
	var g4=document.getElementById("g4").checked;
	var g5=document.getElementById("g5").checked;

	if(g1){stra7=stra7+"g1  ";}
	if(g2){stra7=stra7+"g2  ";}
	if(g3){stra7=stra7+"g3  ";}
	if(g4){stra7=stra7+"g4  ";}
	if(g5){stra7=stra7+"g5  ";}


	var h1=document.getElementById("h1").checked;
	var h2=document.getElementById("h2").checked;
	var h3=document.getElementById("h3").checked;
	var h4=document.getElementById("h4").checked;
	var h5=document.getElementById("h5").checked;
	var h6=document.getElementById("h6").checked;
	var h7=document.getElementById("h7").checked;
	var h8=document.getElementById("h8").checked;
	var h9=document.getElementById("h9").checked;

	if(h1){stra8=stra8+"h1  ";}
	if(h2){stra8=stra8+"h2  ";}
	if(h3){stra8=stra8+"h3  ";}
	if(h4){stra8=stra8+"h4  ";}
	if(h5){stra8=stra8+"h5	";}
	if(h6){stra8=stra8+"h6  ";}
	if(h7){stra8=stra8+"h7  ";}
	if(h8){stra8=stra8+"h8  ";}
	if(h9){stra8=stra8+"h9  ";}


	var i1=document.getElementById("i1").checked;
	var i2=document.getElementById("i2").checked;
	var i3=document.getElementById("i3").checked;
	var i4=document.getElementById("i4").checked;
	var i5=document.getElementById("i5").checked;
	var i6=document.getElementById("i6").checked;
	var i7=document.getElementById("i7").checked;

	if(i1){stra9=stra9+"i1  ";}
	if(i2){stra9=stra9+"i2  ";}
	if(i3){stra9=stra9+"i3  ";}
	if(i4){stra9=stra9+"i4  ";}
	if(i5){stra9=stra9+"i5	";}
	if(i6){stra9=stra9+"i6  ";}
	if(i7){stra9=stra9+"i7  ";}


	
	stra10 = stra10+"<?php echo $_GET["pg_no"];?>  ";
stra10 =stra10+"<?php echo $_GET["sort_by"];?>  ";
	
	
	//var j1=document.getElementById("j1").checked;
	//var j2=document.getElementById("j2").checked;
	//var j3=document.getElementById("j3").checked;
	//var j4=document.getElementById("j4").checked;
	//var j5=document.getElementById("j5").checked;

	//if(j1){stra10=stra10+"j1  ";}
	//if(j2){stra10=stra10+"j2  ";}
	///if(j3){stra10=stra10+"j3  ";}
	//if(j4){stra10=stra10+"j4  ";}
	//if(j5){stra10=stra10+"j5	";}


	var k1=document.getElementById("k1").checked;
	var k2=document.getElementById("k2").checked;
	var k3=document.getElementById("k3").checked;
	var k4=document.getElementById("k4").checked;

	if(k1){stra11=stra11+"k1  ";}
	if(k2){stra11=stra11+"k2  ";}
	if(k3){stra11=stra11+"k3  ";}
	if(k4){stra11=stra11+"k4  ";}




  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("mobileslist").innerHTML =
      this.responseText;
    }
  };

  var obj={"brand":stra1, "ram":stra2,"rom":stra3,"battery":stra4,"price":stra5,"os":stra6,"screen_size":stra7,
  "primary_camera":stra8,"secondary_camera":stra9,"page_number":stra10,"sim_type":stra11};

  var myJSON=JSON.stringify(obj);


  xhttp.open("GET","ajax_filter_result1.php?q="+myJSON, true);
  xhttp.send();


	}
</script>
	
	<div class="box">
	<div class="box-title">
	<p> Mobile Phones Price in India </p>
	<p style="margin-top:-10px;font-size:11px;color:grey;"> Showing 1-20 of 800 Products </p>
	</div>
	<div id="mobileslist">

	
	</div>
	</div>
	
</div>
</body>
</html>