<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" type="image/png" href="http://mobiclues.com/images/latest icon.png" />
<link rel="stylesheet" type="text/css" href="./css/phonefinder.css">
<link rel="stylesheet" type="text/css" href="./css/header.css">
<script src="./scripts/index.js"></script>
<script src="./scripts/phonefinder.js"></script>
<script src="./scripts/ajax_filter.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body style="background-color:#efeded;margin: 0px;font-family: Arial, Helvetica, sans-serif;">
<?php

$q=$_REQUEST["q"];
//echo $q;		
//echo"hiiiiiiiiiiiiiiii";
$book=json_decode($q);
$error = json_last_error();
//echo $error;
//echo "<br>";
//echo $book->brand;
//echo "<br>";
//echo $book->ram;
$brand=explode("  ",$book->brand);
$ram =explode("  ",$book->ram);
$rom=explode("  ",$book->rom);
$battery=explode("  ",$book->battery);
$price=explode("  ",$book->price);
$os=explode("  ",$book->os);
$primary_camera=explode("  ",$book->primary_camera);
$secondary_camera=explode("  ",$book->secondary_camera);
$screen_size =explode("  ",$book->screen_size);
$page_number=explode("  ",$book->page_number);
$sim_type =explode("  ",$book->sim_type);
$result=$book->checked_id;

//if(isset($battery[1])){
//echo $battery[1];}
//echo "<br>";
//echo $screen_size[0];
//echo "<br>";

$servername="mobiclues.c3m2ijmhxwrw.ap-south-1.rds.amazonaws.com";
$username="mobiclues";
$password="iitjstartup.m";


$conn=mysqli_connect($servername,$username, $password,'mydb',"3306");


if(!$conn){
die ("this connection failed: " . mysqli_error());}
//echo "connected successfully";
//echo "<br>";

$qry= "SELECT * FROM allbrands WHERE  1 ";
if(isset($book->brand)&& $book->brand !=""){$qry=$qry."AND (";}
if(isset($brand[0]) && $brand[0]!= ""){$qry=$qry." Brand='$brand[0]'";}
if(isset($brand[1]) && $brand[1]!= ""){$qry=$qry." OR Brand='$brand[1]'";}
if(isset($brand[2])&& $brand[2]!= ""){$qry=$qry." OR Brand='$brand[2]'";}
if(isset($brand[3])&& $brand[3]!= ""){$qry=$qry." OR Brand='$brand[3]'";}
if(isset($brand[4])&& $brand[4]!= ""){$qry=$qry." OR Brand='$brand[4]'";}
if(isset($brand[5])&& $brand[5]!= ""){$qry=$qry." OR Brand='$brand[5]'";}
if(isset($brand[6])&& $brand[6]!= ""){$qry=$qry." OR Brand='$brand[6]'";}
if(isset($brand[7])&& $brand[7]!= ""){$qry=$qry." OR Brand='$brand[7]'";}
if(isset($brand[8])&& $brand[8]!= ""){$qry=$qry." OR Brand='$brand[8]'";}
if(isset($brand[9])&& $brand[9]!= ""){$qry=$qry." OR Brand='$brand[9]'";}
if(isset($brand[10])&& $brand[10]!= ""){$qry=$qry. "OR Brand='$brand[10]'";}
if(isset($brand[11])&& $brand[11]!= ""){$qry=$qry." OR Brand='$brand[11]'";}
if(isset($brand[12])&& $brand[12]!= ""){$qry=$qry." OR Brand='$brand[12]'";}
if(isset($brand[13])&& $brand[1]!= ""){$qry=$qry." OR Brand='$brand[13]'";}
if(isset($brand[14])&& $brand[14]!= ""){$qry=$qry." OR Brand='$brand[14]'";}
if(isset($book->brand)&& $book->brand !=""){$qry=$qry.")";}



if(isset($book->ram)&& $book->ram !=""){$qry=$qry."AND (";}
if(isset($ram[0]) && $ram[0]== "b1"){$qry=$qry." RAM<=1";}
if(isset($ram[0]) && $ram[0]== "b2"){$qry=$qry." RAM=1.5";}
if(isset($ram[0]) && $ram[0]== "b3"){$qry=$qry." RAM=2";}
if(isset($ram[0]) && $ram[0]== "b4"){$qry=$qry." RAM=3";}
if(isset($ram[0]) && $ram[0]== "b5"){$qry=$qry." RAM=4";}
if(isset($ram[0]) && $ram[0]== "b6"){$qry=$qry." RAM=5";}
if(isset($ram[0]) && $ram[0]== "b7"){$qry=$qry." RAM=6";}
if(isset($ram[0]) && $ram[0]== "b8"){$qry=$qry." RAM=7";}
if(isset($ram[0]) && $ram[0]== "b9"){$qry=$qry." RAM=8";}



if(isset($ram[1]) && $ram[1]== "b1"){$qry=$qry." OR RAM<=1";}
if(isset($ram[1]) && $ram[1]== "b2"){$qry=$qry." OR RAM=1.5";}
if(isset($ram[1]) && $ram[1]== "b3"){$qry=$qry." OR RAM=2";}
if(isset($ram[1]) && $ram[1]== "b4"){$qry=$qry." OR RAM=3";}
if(isset($ram[1]) && $ram[1]== "b5"){$qry=$qry." OR RAM=4";}
if(isset($ram[1]) && $ram[1]== "b6"){$qry=$qry." OR RAM=5";}
if(isset($ram[1]) && $ram[1]== "b7"){$qry=$qry." OR RAM=6";}
if(isset($ram[1]) && $ram[1]== "b8"){$qry=$qry." OR RAM=7";}
if(isset($ram[1]) && $ram[1]== "b9"){$qry=$qry." OR RAM=8";}


if(isset($ram[2]) && $ram[2]== "b1"){$qry=$qry." OR RAM<=1";}
if(isset($ram[2]) && $ram[2]== "b2"){$qry=$qry." OR RAM=1.5";}
if(isset($ram[2]) && $ram[2]== "b3"){$qry=$qry." OR RAM=2";}
if(isset($ram[2]) && $ram[2]== "b4"){$qry=$qry." OR RAM=3";}
if(isset($ram[2]) && $ram[2]== "b5"){$qry=$qry." OR RAM=4";}
if(isset($ram[2]) && $ram[2]== "b6"){$qry=$qry." OR RAM=5";}
if(isset($ram[2]) && $ram[2]== "b7"){$qry=$qry." OR RAM=6";}
if(isset($ram[2]) && $ram[2]== "b8"){$qry=$qry." OR RAM=7";}
if(isset($ram[2]) && $ram[2]== "b9"){$qry=$qry." OR RAM=8";}


if(isset($ram[3]) && $ram[3]== "b1"){$qry=$qry." OR RAM<=1";}
if(isset($ram[3]) && $ram[3]== "b2"){$qry=$qry." OR RAM=1.5";}
if(isset($ram[3]) && $ram[3]== "b3"){$qry=$qry." OR RAM=2";}
if(isset($ram[3]) && $ram[3]== "b4"){$qry=$qry." OR RAM=3";}
if(isset($ram[3]) && $ram[3]== "b5"){$qry=$qry." OR RAM=4";}
if(isset($ram[3]) && $ram[3]== "b6"){$qry=$qry." OR RAM=5";}
if(isset($ram[3]) && $ram[3]== "b7"){$qry=$qry." OR RAM=6";}
if(isset($ram[3]) && $ram[3]== "b8"){$qry=$qry." OR RAM=7";}
if(isset($ram[3]) && $ram[3]== "b9"){$qry=$qry." OR RAM=8";}


if(isset($ram[4]) && $ram[4]== "b1"){$qry=$qry." OR RAM<=1";}
if(isset($ram[4]) && $ram[4]== "b2"){$qry=$qry." OR RAM=1.5";}
if(isset($ram[4]) && $ram[4]== "b3"){$qry=$qry." OR RAM=2";}
if(isset($ram[4]) && $ram[4]== "b4"){$qry=$qry." OR RAM=3";}
if(isset($ram[4]) && $ram[4]== "b5"){$qry=$qry." OR RAM=4";}
if(isset($ram[4]) && $ram[4]== "b6"){$qry=$qry." OR RAM=5";}
if(isset($ram[4]) && $ram[4]== "b7"){$qry=$qry." OR RAM=6";}
if(isset($ram[4]) && $ram[4]== "b8"){$qry=$qry." OR RAM=7";}
if(isset($ram[4]) && $ram[4]== "b9"){$qry=$qry." OR RAM=8";}


if(isset($ram[5]) && $ram[5]== "b1"){$qry=$qry." OR RAM<=1";}
if(isset($ram[5]) && $ram[5]== "b2"){$qry=$qry." OR RAM=1.5";}
if(isset($ram[5]) && $ram[5]== "b3"){$qry=$qry." OR RAM=2";}
if(isset($ram[5]) && $ram[5]== "b4"){$qry=$qry." OR RAM=3";}
if(isset($ram[5]) && $ram[5]== "b5"){$qry=$qry." OR RAM=4";}
if(isset($ram[5]) && $ram[5]== "b6"){$qry=$qry." OR RAM=5";}
if(isset($ram[5]) && $ram[5]== "b7"){$qry=$qry." OR RAM=6";}
if(isset($ram[5]) && $ram[5]== "b8"){$qry=$qry." OR RAM=7";}
if(isset($ram[5]) && $ram[5]== "b9"){$qry=$qry." OR RAM=8";}


if(isset($ram[6]) && $ram[6]== "b1"){$qry=$qry." OR RAM<=1";}
if(isset($ram[6]) && $ram[6]== "b2"){$qry=$qry." OR RAM=1.5";}
if(isset($ram[6]) && $ram[6]== "b3"){$qry=$qry." OR RAM=2";}
if(isset($ram[6]) && $ram[6]== "b4"){$qry=$qry." OR RAM=3";}
if(isset($ram[6]) && $ram[6]== "b5"){$qry=$qry." OR RAM=4";}
if(isset($ram[6]) && $ram[6]== "b6"){$qry=$qry." OR RAM=5";}
if(isset($ram[6]) && $ram[6]== "b7"){$qry=$qry." OR RAM=6";}
if(isset($ram[6]) && $ram[6]== "b8"){$qry=$qry." OR RAM=7";}
if(isset($ram[6]) && $ram[6]== "b9"){$qry=$qry." OR RAM=8";}


if(isset($ram[7]) && $ram[7]== "b1"){$qry=$qry." OR RAM<=1";}
if(isset($ram[7]) && $ram[7]== "b2"){$qry=$qry." OR RAM=1.5";}
if(isset($ram[7]) && $ram[7]== "b3"){$qry=$qry." OR RAM=2";}
if(isset($ram[7]) && $ram[7]== "b4"){$qry=$qry." OR RAM=3";}
if(isset($ram[7]) && $ram[7]== "b5"){$qry=$qry." OR RAM=4";}
if(isset($ram[7]) && $ram[7]== "b6"){$qry=$qry." OR RAM=5";}
if(isset($ram[7]) && $ram[7]== "b7"){$qry=$qry." OR RAM=6";}
if(isset($ram[7]) && $ram[7]== "b8"){$qry=$qry." OR RAM=7";}
if(isset($ram[7]) && $ram[7]== "b9"){$qry=$qry." OR RAM=8";}


if(isset($ram[8]) && $ram[8]== "b1"){$qry=$qry." OR RAM<=1";}
if(isset($ram[8]) && $ram[8]== "b2"){$qry=$qry." OR RAM=1.5";}
if(isset($ram[8]) && $ram[8]== "b3"){$qry=$qry." OR RAM=2";}
if(isset($ram[8]) && $ram[8]== "b4"){$qry=$qry." OR RAM=3";}
if(isset($ram[8]) && $ram[8]== "b5"){$qry=$qry." OR RAM=4";}
if(isset($ram[8]) && $ram[8]== "b6"){$qry=$qry." OR RAM=5";}
if(isset($ram[8]) && $ram[8]== "b7"){$qry=$qry." OR RAM=6";}
if(isset($ram[8]) && $ram[8]== "b8"){$qry=$qry." OR RAM=7";}
if(isset($ram[8]) && $ram[8]== "b9"){$qry=$qry." OR RAM=8";}
if(isset($book->ram)&& $book->ram !=""){$qry=$qry.")";}





if(isset($book->rom)&& $book->rom !=""){$qry=$qry."AND (";}
if(isset($rom[0]) && $rom[0]== "c1"){$qry=$qry." Internal_Storage=2";}
if(isset($rom[0]) && $rom[0]== "c2"){$qry=$qry." Internal_Storage=4";}
if(isset($rom[0]) && $rom[0]== "c3"){$qry=$qry." Internal_Storage=8";}
if(isset($rom[0]) && $rom[0]== "c4"){$qry=$qry." Internal_Storage=16";}
if(isset($rom[0]) && $rom[0]== "c5"){$qry=$qry." Internal_Storage=32";}
if(isset($rom[0]) && $rom[0]== "c6"){$qry=$qry." Internal_Storage=64";}
if(isset($rom[0]) && $rom[0]== "c7"){$qry=$qry." Internal_Storage=128";}


if(isset($rom[1]) && $rom[1]== "c1"){$qry=$qry." OR Internal_Storage=2";}
if(isset($rom[1]) && $rom[1]== "c2"){$qry=$qry." OR Internal_Storage=4";}
if(isset($rom[1]) && $rom[1]== "c3"){$qry=$qry." OR Internal_Storage=8";}
if(isset($rom[1]) && $rom[1]== "c4"){$qry=$qry." OR Internal_Storage=16";}
if(isset($rom[1]) && $rom[1]== "c5"){$qry=$qry." OR Internal_Storage=32";}
if(isset($rom[1]) && $rom[1]== "c6"){$qry=$qry." OR Internal_Storage=64";}
if(isset($rom[1]) && $rom[1]== "c7"){$qry=$qry." OR Internal_Storage=128";}


if(isset($rom[2]) && $rom[2]== "c1"){$qry=$qry." OR Internal_Storage=2";}
if(isset($rom[2]) && $rom[2]== "c2"){$qry=$qry." OR Internal_Storage=4";}
if(isset($rom[2]) && $rom[2]== "c3"){$qry=$qry." OR Internal_Storage=8";}
if(isset($rom[2]) && $rom[2]== "c4"){$qry=$qry." OR Internal_Storage=16";}
if(isset($rom[2]) && $rom[2]== "c5"){$qry=$qry." OR Internal_Storage=32";}
if(isset($rom[2]) && $rom[2]== "c6"){$qry=$qry." OR Internal_Storage=64";}
if(isset($rom[2]) && $rom[2]== "c7"){$qry=$qry." OR Internal_Storage=128";}


if(isset($rom[3]) && $rom[3]== "c1"){$qry=$qry." OR Internal_Storage=2";}
if(isset($rom[3]) && $rom[3]== "c2"){$qry=$qry." OR Internal_Storage=4";}
if(isset($rom[3]) && $rom[3]== "c3"){$qry=$qry." OR Internal_Storage=8";}
if(isset($rom[3]) && $rom[3]== "c4"){$qry=$qry." OR Internal_Storage=16";}
if(isset($rom[3]) && $rom[3]== "c5"){$qry=$qry." OR Internal_Storage=32";}
if(isset($rom[3]) && $rom[3]== "c6"){$qry=$qry." OR Internal_Storage=64";}
if(isset($rom[3]) && $rom[3]== "c7"){$qry=$qry." OR Internal_Storage=128";}


if(isset($rom[4]) && $rom[4]== "c1"){$qry=$qry." OR Internal_Storage=2";}
if(isset($rom[4]) && $rom[4]== "c2"){$qry=$qry." OR Internal_Storage=4";}
if(isset($rom[4]) && $rom[4]== "c3"){$qry=$qry." OR Internal_Storage=8";}
if(isset($rom[4]) && $rom[4]== "c4"){$qry=$qry." OR Internal_Storage=16";}
if(isset($rom[4]) && $rom[4]== "c5"){$qry=$qry." OR Internal_Storage=32";}
if(isset($rom[4]) && $rom[4]== "c6"){$qry=$qry." OR Internal_Storage=64";}
if(isset($rom[4]) && $rom[4]== "c7"){$qry=$qry." OR Internal_Storage=128";}


if(isset($rom[5]) && $rom[5]== "c1"){$qry=$qry." OR Internal_Storage=2";}
if(isset($rom[5]) && $rom[5]== "c2"){$qry=$qry." OR Internal_Storage=4";}
if(isset($rom[5]) && $rom[5]== "c3"){$qry=$qry." OR Internal_Storage=8";}
if(isset($rom[5]) && $rom[5]== "c4"){$qry=$qry." OR Internal_Storage=16";}
if(isset($rom[5]) && $rom[5]== "c5"){$qry=$qry." OR Internal_Storage=32";}
if(isset($rom[5]) && $rom[5]== "c6"){$qry=$qry." OR Internal_Storage=64";}
if(isset($rom[5]) && $rom[5]== "c7"){$qry=$qry." OR Internal_Storage=128";}


if(isset($rom[6]) && $rom[6]== "c1"){$qry=$qry." OR Internal_Storage=2";}
if(isset($rom[6]) && $rom[6]== "c2"){$qry=$qry." OR Internal_Storage=4";}
if(isset($rom[6]) && $rom[6]== "c3"){$qry=$qry." OR Internal_Storage=8";}
if(isset($rom[6]) && $rom[6]== "c4"){$qry=$qry." OR Internal_Storage=16";}
if(isset($rom[6]) && $rom[6]== "c5"){$qry=$qry." OR Internal_Storage=32";}
if(isset($rom[6]) && $rom[6]== "c6"){$qry=$qry." OR Internal_Storage=64";}
if(isset($rom[6]) && $rom[6]== "c7"){$qry=$qry." OR Internal_Storage=128";}
if(isset($book->rom)&& $book->rom !=""){$qry=$qry.")";}







if(isset($book->battery)&& $book->battery  !=""){$qry=$qry."AND (";}
if(isset($battery[0])&& $battery[0]=="d1"){$qry=$qry."   Battery_Capacity <=999";}
if(isset($battery[0])&& $battery[0]=="d2"){$qry=$qry."   Battery_Capacity >=1000 AND Battery_Capacity <=1999";}
if(isset($battery[0])&& $battery[0]=="d3"){$qry=$qry."   Battery_Capacity >=2000 AND Battery_Capacity <=2999";}
if(isset($battery[0])&& $battery[0]=="d4"){$qry=$qry."   Battery_Capacity >=3000 AND Battery_Capacity <=3999";}
if(isset($battery[0])&& $battery[0]=="d5"){$qry=$qry."   Battery_Capacity >=4000";}

if(isset($battery[1])&& $battery[1]=="d1"){$qry=$qry."  OR  (Battery_Capacity <=999)";}
if(isset($battery[1])&& $battery[1]=="d2"){$qry=$qry."  OR  (Battery_Capacity >=1000 AND Battery_Capacity <=1999)";}
if(isset($battery[1])&& $battery[1]=="d3"){$qry=$qry."  OR (Battery_Capacity >=2000 AND Battery_Capacity <=2999)";}
if(isset($battery[1])&& $battery[1]=="d4"){$qry=$qry."  OR (Battery_Capacity >=3000 AND Battery_Capacity <=3999)";}
if(isset($battery[1])&& $battery[1]=="d5"){$qry=$qry."  OR (Battery_Capacity >=4000)";}

if(isset($battery[2])&& $battery[2]=="d1"){$qry=$qry."  OR  (Battery_Capacity <=1000)";}
if(isset($battery[2])&& $battery[2]=="d2"){$qry=$qry."  OR  (Battery_Capacity >=1000 AND Battery_Capacity <=1999)";}
if(isset($battery[2])&& $battery[2]=="d3"){$qry=$qry."  OR (Battery_Capacity >=2000 AND Battery_Capacity <=2999)";}
if(isset($battery[2])&& $battery[2]=="d4"){$qry=$qry."  OR (Battery_Capacity >=3000 AND Battery_Capacity <=3999)";}
if(isset($battery[2])&& $battery[2]=="d5"){$qry=$qry."  OR (Battery_Capacity >=4000)";}

if(isset($battery[3])&& $battery[3]=="d1"){$qry=$qry."  OR  (Battery_Capacity <=1000)";}
if(isset($battery[3])&& $battery[3]=="d2"){$qry=$qry."  OR  (Battery_Capacity >=1000 AND Battery_Capacity <=1999)";}
if(isset($battery[3])&& $battery[3]=="d3"){$qry=$qry."  OR (Battery_Capacity >=2000 AND Battery_Capacity <=2999)";}
if(isset($battery[3])&& $battery[3]=="d4"){$qry=$qry."  OR (Battery_Capacity >=3000 AND Battery_Capacity <=3999)";}
if(isset($battery[3])&& $battery[3]=="d5"){$qry=$qry."  OR (Battery_Capacity >=4000)";}

if(isset($battery[4])&& $battery[4]=="d1"){$qry=$qry."  OR  (Battery_Capacity <=1000)";}
if(isset($battery[4])&& $battery[4]=="d2"){$qry=$qry."  OR  (Battery_Capacity >=1000 AND Battery_Capacity <=1999)";}
if(isset($battery[4])&& $battery[4]=="d3"){$qry=$qry."  OR (Battery_Capacity >=2000 AND Battery_Capacity <=2999)";}
if(isset($battery[4])&& $battery[4]=="d4"){$qry=$qry."  OR (Battery_Capacity >=3000 AND Battery_Capacity <=3999)";}
if(isset($battery[4])&& $battery[4]=="d5"){$qry=$qry."  OR (Battery_Capacity >=4000)";}
if(isset($book->battery)&& $book->battery !=""){$qry=$qry.")";}








if(isset($book->price)&& $book->price !=""){$qry=$qry."AND (";}
if(isset($price[0]) && $price[0]== "e1"){$qry=$qry." Price<1000";}
if(isset($price[0]) && $price[0]== "e2"){$qry=$qry." Price>=1000 AND Price<5000";}
if(isset($price[0]) && $price[0]== "e3"){$qry=$qry." Price>=5000 AND Price<10000";}
if(isset($price[0]) && $price[0]== "e4"){$qry=$qry." Price>=10000 AND Price<20000";}
if(isset($price[0]) && $price[0]== "e5"){$qry=$qry." Price>=20000";}


if(isset($price[1]) && $price[1]== "e1"){$qry=$qry." OR Price<1000";}
if(isset($price[1]) && $price[1]== "e2"){$qry=$qry." OR Price>=1000 AND Price<5000";}
if(isset($price[1]) && $price[1]== "e3"){$qry=$qry." OR Price>=5000 AND Price<10000";}
if(isset($price[1]) && $price[1]== "e4"){$qry=$qry." OR Price>=10000 AND Price<20000";}
if(isset($price[1]) && $price[1]== "e5"){$qry=$qry." OR Price>=20000";}


if(isset($price[2]) && $price[2]== "e1"){$qry=$qry." OR Price<1000";}
if(isset($price[2]) && $price[2]== "e2"){$qry=$qry." OR Price>=1000 AND Price<5000";}
if(isset($price[2]) && $price[2]== "e3"){$qry=$qry." OR Price>=5000 AND Price<10000";}
if(isset($price[2]) && $price[2]== "e4"){$qry=$qry." OR Price>=10000 AND Price<20000";}
if(isset($price[2]) && $price[2]== "e5"){$qry=$qry." OR Price>=20000";}


if(isset($price[3]) && $price[3]== "e1"){$qry=$qry." OR Price<1000";}
if(isset($price[3]) && $price[3]== "e2"){$qry=$qry." OR Price>=1000 AND Price<5000";}
if(isset($price[3]) && $price[3]== "e3"){$qry=$qry." OR Price>=5000 AND Price<10000";}
if(isset($price[3]) && $price[3]== "e4"){$qry=$qry." OR Price>=10000 AND Price<20000";}
if(isset($price[3]) && $price[3]== "e5"){$qry=$qry." OR Price>=20000";}


if(isset($price[4]) && $price[4]== "e1"){$qry=$qry." OR Price<1000";}
if(isset($price[4]) && $price[4]== "e2"){$qry=$qry." OR Price>=1000 AND Price<5000";}
if(isset($price[4]) && $price[4]== "e3"){$qry=$qry." OR Price>=5000 AND Price<10000";}
if(isset($price[4]) && $price[4]== "e4"){$qry=$qry." OR Price>=10000 AND Price<20000";}
if(isset($price[4]) && $price[4]== "e5"){$qry=$qry." OR Price>=20000";}
if(isset($book->price)&& $book->price !=""){$qry=$qry.")";}




if(isset($book->os)&& $book->os !=""){$qry=$qry."AND (";}
if(isset($os[0]) && $os[0]== "Android"){$qry=$qry." OS LIKE '%Android%'";}
if(isset($os[0]) && $os[0]== "iOS"){$qry=$qry." OS LIKE '%iOS%'";}
if(isset($os[0]) && $os[0]== "Blackberry"){$qry=$qry." OS LIKE '%Blackberry%'";}
if(isset($os[0]) && $os[0]== "Windows"){$qry=$qry." OS LIKE '%Windows%'";}

if(isset($os[1]) && $os[1]== "Android"){$qry=$qry." OR OS LIKE '%Android%'";}
if(isset($os[1]) && $os[1]== "iOS"){$qry=$qry." OR OS LIKE '%iOS%'";}
if(isset($os[1]) && $os[1]== "Blackberry"){$qry=$qry." OR OS LIKE '%Blackberry%'";}
if(isset($os[1]) && $os[1]== "Windows"){$qry=$qry." OR OS LIKE '%Windows%'";}

if(isset($os[2]) && $os[2]== "Android"){$qry=$qry." OR OS LIKE '%Android%'";}
if(isset($os[2]) && $os[2]== "iOS"){$qry=$qry." OR OS LIKE '%iOS%'";}
if(isset($os[2]) && $os[2]== "Blackberry"){$qry=$qry." OR OS LIKE '%Blackberry%'";}
if(isset($os[2]) && $os[2]== "Windows"){$qry=$qry." OR OS LIKE '%Windows%'";}

if(isset($os[3]) && $os[3]== "Android"){$qry=$qry." OR OS LIKE '%Android%'";}
if(isset($os[3]) && $os[3]== "iOS"){$qry=$qry." OR OS LIKE '%iOS%'";}
if(isset($os[3]) && $os[3]== "Blackberry"){$qry=$qry." OR OS LIKE '%Blackberry%'";}
if(isset($os[3]) && $os[3]== "Windows"){$qry=$qry." OR OS LIKE '%Windows%'";}



if(isset($book->os)&& $book->os !=""){$qry=$qry.")";}



if(isset($book->screen_size)&& $book->screen_size  !=""){$qry=$qry."AND (";}
if(isset($screen_size[0])&& $screen_size[0]=="g1"){$qry=$qry."   Display_Size <=3.9";}
if(isset($screen_size[0])&& $screen_size[0]=="g2"){$qry=$qry."   Display_Size >=4 AND Display_Size <=4.4";}
if(isset($screen_size[0])&& $screen_size[0]=="g3"){$qry=$qry."   Display_Size >=4.5 AND Display_Size <=4.9";}
if(isset($screen_size[0])&& $screen_size[0]=="g4"){$qry=$qry."   Display_Size >=5 AND Display_Size <=5.4";}
if(isset($screen_size[0])&& $screen_size[0]=="g5"){ $qry=$qry."   Display_Size >=5.5 ";}


if(isset($screen_size[1])&& $screen_size[1]=="g1"){$qry=$qry."  OR Display_Size <=3.9";}
if(isset($screen_size[1])&& $screen_size[1]=="g2"){$qry=$qry."  OR  Display_Size >=4 AND Display_Size <=4.4";}
if(isset($screen_size[1])&& $screen_size[1]=="g3"){$qry=$qry."  OR  Display_Size >=4.5 AND Display_Size <=4.9";}
if(isset($screen_size[1])&& $screen_size[1]=="g4"){$qry=$qry."  OR  Display_Size >=5 AND Display_Size <=5.4";}
if(isset($screen_size[1])&& $screen_size[1]=="g5"){$qry=$qry."  OR  Display_Size >=5.5";}

if(isset($screen_size[2])&& $screen_size[2]=="g1"){$qry=$qry."   OR Display_Size <=3.9";}
if(isset($screen_size[2])&& $screen_size[2]=="g2"){$qry=$qry."   OR Display_Size >=4 AND Display_Size <=4.4";}
if(isset($screen_size[2])&& $screen_size[2]=="g3"){$qry=$qry."   OR Display_Size >=4.5 AND Display_Size <=4.9";}
if(isset($screen_size[2])&& $screen_size[2]=="g4"){$qry=$qry."   OR Display_Size >=5 AND Display_Size <=5.4";}
if(isset($screen_size[2])&& $screen_size[2]=="g5"){$qry=$qry."   OR Display_Size >=5.5";}

if(isset($screen_size[3])&& $screen_size[3]=="g1"){$qry=$qry."   OR Display_Size <=3.9";}
if(isset($screen_size[3])&& $screen_size[3]=="g2"){$qry=$qry."   OR Display_Size >=4 AND Display_Size <=4.4";}
if(isset($screen_size[3])&& $screen_size[3]=="g3"){$qry=$qry."   OR Display_Size >=4.5 AND Display_Size <=4.9";}
if(isset($screen_size[3])&& $screen_size[3]=="g4"){$qry=$qry."   OR Display_Size >=5 AND Display_Size <=5.4";}
if(isset($screen_size[3])&& $screen_size[3]=="g5"){$qry=$qry."   OR Display_Size >=5.5";}

if(isset($screen_size[4])&& $screen_size[4]=="g1"){$qry=$qry."   OR Display_Size <=3.9";}
if(isset($screen_size[4])&& $screen_size[4]=="g2"){$qry=$qry."   OR Display_Size >=4 AND Display_Size <=4.4";}
if(isset($screen_size[4])&& $screen_size[4]=="g3"){$qry=$qry."   OR Display_Size >=4.5 AND Display_Size <=4.9";}
if(isset($screen_size[4])&& $screen_size[4]=="g4"){$qry=$qry."   OR Display_Size >=5 AND Display_Size <=5.4";}
if(isset($screen_size[4])&& $screen_size[4]=="g5"){$qry=$qry."   OR Display_Size >=5.5";} 
if(isset($book->screen_size)&& $book->screen_size !=""){$qry=$qry.")";}




if(isset($book->primary_camera)&& $book->primary_camera  !=""){$qry=$qry."AND (";}
if(isset($primary_camera[0])&& $primary_camera[0]=="h1"){$qry=$qry."   	Primary_Camera_for_search <2";}
if(isset($primary_camera[0])&& $primary_camera[0]=="h2"){$qry=$qry."   	Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[0])&& $primary_camera[0]=="h3"){$qry=$qry."   	Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[0])&& $primary_camera[0]=="h4"){$qry=$qry."   	Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[0])&& $primary_camera[0]=="h5"){$qry=$qry."   	Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[0])&& $primary_camera[0]=="h6"){$qry=$qry."   	Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[0])&& $primary_camera[0]=="h7"){$qry=$qry."   	Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[0])&& $primary_camera[0]=="h8"){$qry=$qry."   	Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[0])&& $primary_camera[0]=="h9"){$qry=$qry."   	Primary_Camera_for_search >=21 ";}



if(isset($primary_camera[1])&& $primary_camera[1]=="h1"){$qry=$qry."  OR  Primary_Camera_for_search <2";}
if(isset($primary_camera[1])&& $primary_camera[1]=="h2"){$qry=$qry."   OR Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[1])&& $primary_camera[1]=="h3"){$qry=$qry."  OR  Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[1])&& $primary_camera[1]=="h4"){$qry=$qry."   OR Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[1])&& $primary_camera[1]=="h5"){$qry=$qry."   OR Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[1])&& $primary_camera[1]=="h6"){$qry=$qry."   OR Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[1])&& $primary_camera[1]=="h7"){$qry=$qry."   OR Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[1])&& $primary_camera[1]=="h8"){$qry=$qry."   OR Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[1])&& $primary_camera[1]=="h9"){$qry=$qry."   OR Primary_Camera_for_search >=21 ";}



if(isset($primary_camera[2])&& $primary_camera[2]=="h1"){$qry=$qry."   OR Primary_Camera_for_search <2";}
if(isset($primary_camera[2])&& $primary_camera[2]=="h2"){$qry=$qry."  OR  Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[2])&& $primary_camera[2]=="h3"){$qry=$qry."   OR Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[2])&& $primary_camera[2]=="h4"){$qry=$qry."   OR Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[2])&& $primary_camera[2]=="h5"){$qry=$qry."   OR Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[2])&& $primary_camera[2]=="h6"){$qry=$qry."   OR Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[2])&& $primary_camera[2]=="h7"){$qry=$qry."   OR Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[2])&& $primary_camera[2]=="h8"){$qry=$qry."   OR Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[2])&& $primary_camera[2]=="h9"){$qry=$qry."   OR Primary_Camera_for_search >=21 ";}


if(isset($primary_camera[3])&& $primary_camera[3]=="h1"){$qry=$qry."   OR Primary_Camera_for_search <2";}
if(isset($primary_camera[3])&& $primary_camera[3]=="h2"){$qry=$qry."   OR Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[3])&& $primary_camera[3]=="h3"){$qry=$qry."   OR Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[3])&& $primary_camera[3]=="h4"){$qry=$qry."   OR Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[3])&& $primary_camera[3]=="h5"){$qry=$qry."   OR Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[3])&& $primary_camera[3]=="h6"){$qry=$qry."   OR Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[3])&& $primary_camera[3]=="h7"){$qry=$qry."   OR Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[3])&& $primary_camera[3]=="h8"){$qry=$qry."   OR Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[3])&& $primary_camera[3]=="h9"){$qry=$qry."   OR Primary_Camera_for_search >=21 ";}

if(isset($primary_camera[4])&& $primary_camera[4]=="h1"){$qry=$qry."   OR Primary_Camera_for_search <2";}
if(isset($primary_camera[4])&& $primary_camera[4]=="h2"){$qry=$qry."   OR Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[4])&& $primary_camera[4]=="h3"){$qry=$qry."   OR Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[4])&& $primary_camera[4]=="h4"){$qry=$qry."   OR Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[4])&& $primary_camera[4]=="h5"){$qry=$qry."   OR Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[4])&& $primary_camera[4]=="h6"){$qry=$qry."   OR Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[4])&& $primary_camera[4]=="h7"){$qry=$qry."   OR Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[4])&& $primary_camera[4]=="h8"){$qry=$qry."   OR Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[4])&& $primary_camera[4]=="h9"){$qry=$qry."   OR Primary_Camera_for_search >=21 ";}


if(isset($primary_camera[5])&& $primary_camera[5]=="h1"){$qry=$qry."   OR Primary_Camera_for_search <2";}
if(isset($primary_camera[5])&& $primary_camera[5]=="h2"){$qry=$qry."   OR Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[5])&& $primary_camera[5]=="h3"){$qry=$qry."   OR Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[5])&& $primary_camera[5]=="h4"){$qry=$qry."   OR Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[5])&& $primary_camera[5]=="h5"){$qry=$qry."   OR Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[5])&& $primary_camera[5]=="h6"){$qry=$qry."   OR Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[5])&& $primary_camera[5]=="h7"){$qry=$qry."   OR Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[5])&& $primary_camera[5]=="h8"){$qry=$qry."   OR Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[5])&& $primary_camera[5]=="h9"){$qry=$qry."   OR Primary_Camera_for_search >=21 ";}

if(isset($primary_camera[6])&& $primary_camera[6]=="h1"){$qry=$qry."   OR Primary_Camera_for_search <2";}
if(isset($primary_camera[6])&& $primary_camera[6]=="h2"){$qry=$qry."   OR Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[6])&& $primary_camera[6]=="h3"){$qry=$qry."   OR Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[6])&& $primary_camera[6]=="h4"){$qry=$qry."   OR Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[6])&& $primary_camera[6]=="h5"){$qry=$qry."   OR Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[6])&& $primary_camera[6]=="h6"){$qry=$qry."   OR Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[6])&& $primary_camera[6]=="h7"){$qry=$qry."   OR Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[6])&& $primary_camera[6]=="h8"){$qry=$qry."   OR Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[6])&& $primary_camera[6]=="h9"){$qry=$qry."   OR Primary_Camera_for_search >=21 ";}

if(isset($primary_camera[7])&& $primary_camera[7]=="h1"){$qry=$qry."   OR Primary_Camera_for_search <2";}
if(isset($primary_camera[7])&& $primary_camera[7]=="h2"){$qry=$qry."   OR Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[7])&& $primary_camera[7]=="h3"){$qry=$qry."   OR Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[7])&& $primary_camera[7]=="h4"){$qry=$qry."   OR Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[7])&& $primary_camera[7]=="h5"){$qry=$qry."   OR Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[7])&& $primary_camera[7]=="h6"){$qry=$qry."   OR Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[7])&& $primary_camera[7]=="h7"){$qry=$qry."   OR Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[7])&& $primary_camera[7]=="h8"){$qry=$qry."   OR Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[7])&& $primary_camera[7]=="h9"){$qry=$qry."   OR Primary_Camera_for_search >=21 ";}

if(isset($primary_camera[8])&& $primary_camera[8]=="h1"){$qry=$qry."   OR Primary_Camera_for_search <2";}
if(isset($primary_camera[8])&& $primary_camera[8]=="h2"){$qry=$qry."   OR Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[8])&& $primary_camera[8]=="h3"){$qry=$qry."   OR Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[8])&& $primary_camera[8]=="h4"){$qry=$qry."   OR Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[8])&& $primary_camera[8]=="h5"){$qry=$qry."   OR Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[8])&& $primary_camera[8]=="h6"){$qry=$qry."   OR Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[8])&& $primary_camera[8]=="h7"){$qry=$qry."   OR Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[8])&& $primary_camera[8]=="h8"){$qry=$qry."   OR Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[8])&& $primary_camera[8]=="h9"){$qry=$qry."   OR Primary_Camera_for_search >=21 ";}

if(isset($primary_camera[9])&& $primary_camera[9]=="h1"){$qry=$qry."   OR Primary_Camera_for_search <2";}
if(isset($primary_camera[9])&& $primary_camera[9]=="h2"){$qry=$qry."   OR Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[9])&& $primary_camera[9]=="h3"){$qry=$qry."   OR Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[9])&& $primary_camera[9]=="h4"){$qry=$qry."   OR Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[9])&& $primary_camera[9]=="h5"){$qry=$qry."   OR Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[9])&& $primary_camera[9]=="h6"){$qry=$qry."   OR Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[9])&& $primary_camera[9]=="h7"){$qry=$qry."   OR Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[9])&& $primary_camera[9]=="h8"){$qry=$qry."   OR Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[9])&& $primary_camera[9]=="h9"){$qry=$qry."   OR Primary_Camera_for_search >=21 ";}


if(isset($primary_camera[10])&& $primary_camera[10]=="h1"){$qry=$qry."   OR Primary_Camera_for_search <2";}
if(isset($primary_camera[10])&& $primary_camera[10]=="h2"){$qry=$qry."   OR Primary_Camera_for_search >=2 AND Primary_Camera_for_search <=2.9";}
if(isset($primary_camera[10])&& $primary_camera[10]=="h3"){$qry=$qry."   OR Primary_Camera_for_search >=3 AND Primary_Camera_for_search <=4.9";}
if(isset($primary_camera[10])&& $primary_camera[10]=="h4"){$qry=$qry."   OR Primary_Camera_for_search >=5 AND Primary_Camera_for_search <=7.9";}
if(isset($primary_camera[10])&& $primary_camera[10]=="h5"){$qry=$qry."   OR Primary_Camera_for_search >=8 AND Primary_Camera_for_search <=11.9";}
if(isset($primary_camera[10])&& $primary_camera[10]=="h6"){$qry=$qry."   OR Primary_Camera_for_search <=12 AND Primary_Camera_for_search <=12.9";}
if(isset($primary_camera[10])&& $primary_camera[10]=="h7"){$qry=$qry."   OR Primary_Camera_for_search >=13 AND Primary_Camera_for_search <=15.9";}
if(isset($primary_camera[10])&& $primary_camera[10]=="h8"){$qry=$qry."   OR Primary_Camera_for_search >=16 AND Primary_Camera_for_search <=20.9";}
if(isset($primary_camera[10])&& $primary_camera[10]=="h9"){$qry=$qry."   OR Primary_Camera_for_search >=21 ";}
if(isset($book->primary_camera)&& $book->primary_camera !=""){$qry=$qry.")";}






if(isset($book->secondary_camera)&& $book->secondary_camera  !=""){$qry=$qry."AND (";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i1"){$qry=$qry."   	Secondary_Camera_for_search <2";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i2"){$qry=$qry."   	Secondary_Camera_for_search >=2 AND Secondary_Camera_for_search <=2.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i3"){$qry=$qry."   	Secondary_Camera_for_search >=3 AND Secondary_Camera_for_search <=4.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i4"){$qry=$qry."   	Secondary_Camera_for_search >=5 AND Secondary_Camera_for_search <=7.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i5"){$qry=$qry."   	Secondary_Camera_for_search >=8 AND Secondary_Camera_for_search <=11.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i6"){$qry=$qry."   	Secondary_Camera_for_search <=12 AND Secondary_Camera_for_search <=15.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i7"){$qry=$qry."   	Secondary_Camera_for_search >=16 AND Secondary_Camera_for_search <=21 ";}

if(isset($secondary_camera[0])&& $secondary_camera[0]=="i1"){$qry=$qry."   OR Secondary_Camera_for_search <2";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i2"){$qry=$qry."   	OR Secondary_Camera_for_search >=2 AND Secondary_Camera_for_search <=2.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i3"){$qry=$qry."   	OR Secondary_Camera_for_search >=3 AND Secondary_Camera_for_search <=4.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i4"){$qry=$qry."   	OR Secondary_Camera_for_search >=5 AND Secondary_Camera_for_search <=7.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i5"){$qry=$qry."   	OR Secondary_Camera_for_search >=8 AND Secondary_Camera_for_search <=11.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i6"){$qry=$qry."   OR 	Secondary_Camera_for_search <=12 AND Secondary_Camera_for_search <=15.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i7"){$qry=$qry."   OR	Secondary_Camera_for_search >=16 AND Secondary_Camera_for_search <=21 ";}


if(isset($secondary_camera[0])&& $secondary_camera[0]=="i1"){$qry=$qry."   OR Secondary_Camera_for_search <2";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i2"){$qry=$qry."   	OR Secondary_Camera_for_search >=2 AND Secondary_Camera_for_search <=2.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i3"){$qry=$qry."   	OR Secondary_Camera_for_search >=3 AND Secondary_Camera_for_search <=4.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i4"){$qry=$qry."   	OR Secondary_Camera_for_search >=5 AND Secondary_Camera_for_search <=7.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i5"){$qry=$qry."   	OR Secondary_Camera_for_search >=8 AND Secondary_Camera_for_search <=11.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i6"){$qry=$qry."   OR 	Secondary_Camera_for_search <=12 AND Secondary_Camera_for_search <=15.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i7"){$qry=$qry."   OR	Secondary_Camera_for_search >=16 AND Secondary_Camera_for_search <=21 ";}


if(isset($secondary_camera[0])&& $secondary_camera[0]=="i1"){$qry=$qry."   OR Secondary_Camera_for_search <2";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i2"){$qry=$qry."   	OR Secondary_Camera_for_search >=2 AND Secondary_Camera_for_search <=2.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i3"){$qry=$qry."   	OR Secondary_Camera_for_search >=3 AND Secondary_Camera_for_search <=4.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i4"){$qry=$qry."   	OR Secondary_Camera_for_search >=5 AND Secondary_Camera_for_search <=7.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i5"){$qry=$qry."   	OR Secondary_Camera_for_search >=8 AND Secondary_Camera_for_search <=11.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i6"){$qry=$qry."   OR 	Secondary_Camera_for_search <=12 AND Secondary_Camera_for_search <=15.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i7"){$qry=$qry."   OR	Secondary_Camera_for_search >=16 AND Secondary_Camera_for_search <=21 ";}


if(isset($secondary_camera[0])&& $secondary_camera[0]=="i1"){$qry=$qry."   OR Secondary_Camera_for_search <2";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i2"){$qry=$qry."   	OR Secondary_Camera_for_search >=2 AND Secondary_Camera_for_search <=2.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i3"){$qry=$qry."   	OR Secondary_Camera_for_search >=3 AND Secondary_Camera_for_search <=4.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i4"){$qry=$qry."   	OR Secondary_Camera_for_search >=5 AND Secondary_Camera_for_search <=7.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i5"){$qry=$qry."   	OR Secondary_Camera_for_search >=8 AND Secondary_Camera_for_search <=11.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i6"){$qry=$qry."   OR 	Secondary_Camera_for_search <=12 AND Secondary_Camera_for_search <=15.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i7"){$qry=$qry."   OR	Secondary_Camera_for_search >=16 AND Secondary_Camera_for_search <=21 ";}


if(isset($secondary_camera[0])&& $secondary_camera[0]=="i1"){$qry=$qry."   OR Secondary_Camera_for_search <2";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i2"){$qry=$qry."   	OR Secondary_Camera_for_search >=2 AND Secondary_Camera_for_search <=2.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i3"){$qry=$qry."   	OR Secondary_Camera_for_search >=3 AND Secondary_Camera_for_search <=4.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i4"){$qry=$qry."   	OR Secondary_Camera_for_search >=5 AND Secondary_Camera_for_search <=7.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i5"){$qry=$qry."   	OR Secondary_Camera_for_search >=8 AND Secondary_Camera_for_search <=11.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i6"){$qry=$qry."   OR 	Secondary_Camera_for_search <=12 AND Secondary_Camera_for_search <=15.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i7"){$qry=$qry."   OR	Secondary_Camera_for_search >=16 AND Secondary_Camera_for_search <=21 ";}


if(isset($secondary_camera[0])&& $secondary_camera[0]=="i1"){$qry=$qry."   OR Secondary_Camera_for_search <2";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i2"){$qry=$qry."   	OR Secondary_Camera_for_search >=2 AND Secondary_Camera_for_search <=2.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i3"){$qry=$qry."   	OR Secondary_Camera_for_search >=3 AND Secondary_Camera_for_search <=4.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i4"){$qry=$qry."   	OR Secondary_Camera_for_search >=5 AND Secondary_Camera_for_search <=7.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i5"){$qry=$qry."   	OR Secondary_Camera_for_search >=8 AND Secondary_Camera_for_search <=11.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i6"){$qry=$qry."   OR 	Secondary_Camera_for_search <=12 AND Secondary_Camera_for_search <=15.9";}
if(isset($secondary_camera[0])&& $secondary_camera[0]=="i7"){$qry=$qry."   OR	Secondary_Camera_for_search >=16 AND Secondary_Camera_for_search <=21 ";}
if(isset($book->secondary_camera)&& $book->secondary_camera !=""){$qry=$qry.")";}








if(isset($book->sim_type)&& $book->sim_type !=""){$qry=$qry."AND (";}
if(isset($sim_type[0]) && $sim_type[0]== "k1"){$qry=$qry." 	No_of_SIM=1";}
if(isset($sim_type[0]) && $sim_type[0]== "k2"){$qry=$qry." 	No_of_SIM=2";}
if(isset($sim_type[0]) && $sim_type[0]== "k3"){$qry=$qry." 	No_of_SIM=3";}
if(isset($sim_type[0]) && $sim_type[0]== "k4"){$qry=$qry." 	No_of_SIM=4";}

if(isset($sim_type[1]) && $sim_type[1]== "k1"){$qry=$qry." 	No_of_SIM=1";}
if(isset($sim_type[1]) && $sim_type[1]== "k2"){$qry=$qry." 	No_of_SIM=2";}
if(isset($sim_type[1]) && $sim_type[1]== "k3"){$qry=$qry." 	No_of_SIM=3";}
if(isset($sim_type[1]) && $sim_type[1]== "k4"){$qry=$qry." 	No_of_SIM=4";}

if(isset($sim_type[2]) && $sim_type[2]== "k1"){$qry=$qry." 	No_of_SIM=1";}
if(isset($sim_type[2]) && $sim_type[2]== "k2"){$qry=$qry." 	No_of_SIM=2";}
if(isset($sim_type[2]) && $sim_type[2]== "k3"){$qry=$qry." 	No_of_SIM=3";}
if(isset($sim_type[2]) && $sim_type[2]== "k4"){$qry=$qry." 	No_of_SIM=4";}

if(isset($sim_type[4]) && $sim_type[4]== "k1"){$qry=$qry." 	No_of_SIM=1";}
if(isset($sim_type[4]) && $sim_type[4]== "k2"){$qry=$qry." 	No_of_SIM=2";}
if(isset($sim_type[4]) && $sim_type[4]== "k3"){$qry=$qry." 	No_of_SIM=3";}
if(isset($sim_type[4]) && $sim_type[4]== "k4"){$qry=$qry." 	No_of_SIM=4";}
if(isset($book->sim_type)&& $book->sim_type !=""){$qry=$qry.")";}


//echo "<br>";
if( $page_number[0]!=x){
$pg=0;}
else {$pg=("$page_number[1]"-1)*20;}

$qry=$qry." ORDER BY ID ASC";

$mysql_res=mysqli_query($conn,$qry);
$numberofrows=mysqli_num_rows($mysql_res);
$qry=$qry." LIMIT "."$pg".',20';
//echo $qry;

$mysql_result=mysqli_query($conn,$qry) or die("Error in firing query".mysqli_error($conn));
 
//echo "<br>";
//echo $numberofrows;







if($numberofrows==0){echo '<br>'.'<b>'."!! No Search Results Found !!".'</b>';}
if($numberofrows){while($row=(mysqli_fetch_assoc($mysql_result))){
	
	$brand=$row["Brand"];
	 $model=$row["Model_Name"];
	 $os=$row["OS"];
	 if($row["Display_Size"]==4 || $row["Display_Size"]==5 || $row["Display_Size"]==6){$display_size=(int)$row["Display_Size"];}
	 else{$display_size=$row["Display_Size"];}
	 $cpu=$row["CPU"];
	 $chipset=$row["Chipset"];
	if($row["RAM"]>=1){ $ram=(int)$row["RAM"];}
	else{$ram=1000*$row["RAM"];}
	 $rear_camera=$row["Primary_Camera"];
	 $battery=(int)$row["Battery_Capacity"];
	 $battery_removable=$row["Removable_Battery"];
	 $rom=(int)$row["Internal_Storage"];
	 $rom_expand=$row["Expandable"];
	 $front_camera=$row["Secondary_Camera"];
	 $wlan=$row["WLAN"];
	 $bluetooth=$row["Bluetooth"];
	 $usb=$row["USB"];
	 $dimension=$row["Dimensions"];
	 $weight=$row["Weight"];
	 $colors=$row["Colors"];
	 $released=$row["Released_In"];
	 $technology=$row["Technology"];
	 $two_g=$row["Column_2G_Band"];
	 $three_g=$row["Column_3G_bands"];
	 $four_g=$row["Column_4G_bands"];
	 $sim_type=$row["SIM_Type"];
	 $sb_ratio=$row["Screen_to_body_Ratio"];
	 $resolution=$row["Resolution"];
	 $pixel_density=$row["Pixel_Density"];
	 $multitouch=$row["Multitouch"];
	 $protection=$row["Protection"];
	 $display_type=$row["Display_Type"];
	 $gpu=$row["GPU"];
	 $slot=$row["Card_Slot"];
	 $flash=$row["Primary_Camera_Flash"];
	 $video=$row["Primary_Camera_Video_Quality"];
	 $other_feature=$row["Primary_Camera_Features"];
	 $secondary_camera_video=$row["Secondary_Camera_Video_Quality"];
	 $battery_type=$row["Battery_Type"];
	 $stand_by=$row["Stand_by"];
	 $talktime=$row["Talk_time"];
	 $fast_charging=$row["Fast_Charging"];
	 $gps=$row["GPS"];
	 $nfc=$row["NFC"];
	 $radio=$row["Radio"];
	 $usb=$row["USB"];
	 $jack=$row["Column_3_5mm_jack"];
	 $finger_print=$row["Fingerprint_Sensor"];
	 $other_sensors=$row["Other_Sensors"];
	
	
	echo'<a href="/mobi.php?model='."$model".'"  target="_blank"><div class="mobilebox">';
				echo'<div class="img">';
				echo'<img class="mobileimg" src="http://mobiclues.com/photos/';echo $brand;echo'/';echo $model;echo'/1.jpg" ';
				echo '</div>';
				echo'<div class="detail">';
				
				echo'<p class="mobilename">';echo "$brand" ; echo" $model" ; echo '</p>';
				echo'<p class="mobileprice"> &#8377 N/A </p>';
				echo '<div class="two">';
				echo '<p class="os">';echo'<i class="fa fa-hdd-o">';echo'</i>';
				echo'<span class="featuretext">'; echo "$ram"; if($ram < 100){echo' GB';} else{ echo ' MB';} echo ' RAM ';echo '</p>';
				echo '<p class="os">';echo '<i class="fa fa-mobile">';echo'</i>';
				echo '<span class="featuretext">';echo "$display_size";echo' inches Display ';echo '</p>';
				echo '</div>';
				
				
				
				echo'<div class="two">';
				echo'<p class="os">';echo'<i class="fa fa-camera">';echo '</i>';echo '<span class="featuretext">';echo "$rear_camera";echo' MP';echo '</p>';
				echo'<p class="os">';echo'<i class="fa fa-battery-3">';echo '</i>';echo '<span class="featuretext">';echo "$battery";echo' mAh';echo '</p>';
				echo'</div>';
				echo'</div>';
			echo'</div></a>';
			$p++;
	}}
	
	
	$nextpage=$pg/20+2;
	$previouspage=$pg/20;
	$lastpage=ceil($numberofrows/20);
	
	
	 $p=$p+$pg;
	if($numberofrows==$p && $numberofrows !=0){echo '<div class="endresults">'.'<p>'.'!!  No More Search Results Found  !!'.'</p>'.'</div>';}
	
	if($pg !=0){echo'<div class="firstlast" style="margin-left:320px;"> <a style="text-decoration:none;" href="/phonefinder.php?pg_no=1&vars=';echo"$result"; if(isset($_GET["brand"])){echo '&brand=',"$q";} echo'">First</a> </div>';}
	
	if($pg !=0){echo'<div class="firstlast" style="margin-left:440px;"> <a style="text-decoration:none;" href="/phonefinder.php?pg_no='."$previouspage".'&vars=';echo"$result"; if(isset($_GET["brand"])){echo '&brand=',"$q";}echo'">Previous</a> </div>';}
	
	if($numberofrows-$pg>20){echo'<div class="firstlast" style="margin-left:560px;"> <a style="text-decoration:none;" href="/phonefinder.php?pg_no='."$nextpage".'&vars=';echo"$result"; if(isset($_GET["brand"])){echo '&brand=',"$q";} echo'">Next</a> </div>';}
	
	if($numberofrows-$pg>20){echo'<div class="firstlast" style="margin-left:680px;"> <a style="text-decoration:none;" href="/phonefinder.php?pg_no='."$lastpage".'&vars=';echo"$result"; if(isset($_GET["brand"])){echo '&brand=',"$q";}echo'">Last</a> </div>';}
	
	
	
   mysqli_close($conn);



?>
</body>
</html>  